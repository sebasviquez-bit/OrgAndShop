package Pages;

import Helpers.DriverHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static java.lang.Thread.sleep;


public class ExpertAdvice {

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[2]")
    WebElement menuexpadv;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[2]/div[1]/div/div/div[2]/a")
    WebElement artexpadv;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[1]/ul/li[1]/a")
    WebElement allcateg;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[1]/ul/li[2]/a")
    WebElement dogbreeding;

    @FindBy(css = "#expert-advice > div:nth-child(2) > div > div > div:nth-child(1) > ul > li:nth-child(3) > a")
    WebElement grooming;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[1]/ul/li[4]/a")
    WebElement health;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[1]/ul/li[5]/a")
    WebElement homeliving;

    @FindBy(css = "#expert-advice > div:nth-child(2) > div > div > div:nth-child(1) > ul > li:nth-child(6) > a")
    WebElement lifestyle;

    @FindBy(css = "#expert-advice > div:nth-child(2) > div > div > div:nth-child(2) > ul > li:nth-child(1) > a")
    WebElement news;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[2]/a")
    WebElement nutrition;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[3]/a")
    WebElement puppyinfo;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[4]/a")
    WebElement sports;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[5]/a")
    WebElement training;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[6]/a")
    WebElement vetcorner;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[3]/div/div/div/ul/li[1]/a/div")
    WebElement findmatch;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[2]/div[3]/div/div/div/ul/li[2]/a/div")
    WebElement dognamefind;

    @FindBy(xpath = "//*[@id=\"expert-advice\"]/div[3]/div/div/div/ul/li[3]/a/div")
    WebElement candogeat;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(1) > a")
    WebElement akctv;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(2) > a")
    WebElement akcmag;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(3) > a")
    WebElement newsletter;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(4) > a")
    WebElement presscenter;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(5) > a")
    WebElement akcdetection;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(6) > a")
    WebElement akccanine;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(7) > a")
    WebElement government;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(8) > a")
    WebElement akceducation;

    @FindBy(css = "#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(9) > a")
    WebElement akclibrary;

    @FindBy(xpath = "//html/body/div[14]/div/div/a")
    WebElement closeadd;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/div[1]/h1")
    WebElement artexpadvElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[2]/div[1]/h1")
    WebElement allcategElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/main/div[1]/div[1]/div/h1")
    WebElement dogbreedingElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/main/div[1]/div[1]/div/h1")
    WebElement groomingElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/main/div[1]/div[1]/div/h1")
    WebElement healthElement;

    @FindBy(xpath = "//*[@id=\"page-title\"]/div/h1")
    WebElement homelivingElement;

    @FindBy(css = "body > div:nth-child(6) > div.page-container > div.page-layout > aside > div > nav > h4")
    WebElement lifestyleElement;

    @FindBy(xpath = "//*[@id=\"page-title\"]/div/h1")
    WebElement newsElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/main/div[1]/div[1]/div/h1")
    WebElement nutritionElement;

    @FindBy(xpath = "//*[@id=\"page-title\"]/div/h1")
    WebElement puppyinfoElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/aside/div/nav/h4")
    WebElement sportsElement;

    @FindBy(xpath = "/html/body/div[5]/div[1]/div[3]/aside/div/nav/ul/li[1]/a")
    WebElement trainingElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/main/div[1]/div[1]/div/h1")
    WebElement vetcornerElement;

    @FindBy(xpath = "//html/body/div[7]/div/div/ul/li[2]/span")
    WebElement findmatchElement;

    @FindBy(xpath = "//html/body/main/div[2]/section/div[1]/h2[2]")
    WebElement dognamefindElement;

    @FindBy(xpath = "//html/body/main/div/section/h1")
    WebElement candogeatElement;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/aside/div/nav/h4")
    WebElement akcmagElement;

    @FindBy(xpath = "//*[@id=\"subscription__main-title\"]/h1")
    WebElement newsletterElement;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/aside/div/nav/ul/li[2]/a")
    WebElement presscenterElement;

    @FindBy(xpath = "//*[@id=\"page-title\"]/div/h1")
    WebElement akcdetectionElement;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/aside/div/nav/h4")
    WebElement governmentElement;

    @FindBy(xpath = "//*[@id=\"page-title\"]/div/h1")
    WebElement akceducationElement;

    @FindBy(xpath = "//html/body/div[5]/div/ul/li[3]/span")
    WebElement akclibraryElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[4]/main/div[3]/form/div/div[1]/label[1]/span[1]")
    WebElement allcategBox1;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/main/div[2]/form/div/div/label/span[1]")
    WebElement VideosBox;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/main/div[3]/div/div/div[1]/div/div[2]/a")
    WebElement Video1;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/main/div[3]/div/div/div[1]/div/div[2]/a")
    WebElement nails;

    @FindBy(xpath = "/html/body/div[5]/div[1]/div[3]/aside/div/div[1]/span")
    WebElement mediatitle;

    @FindBy(xpath = "/html/body/div[5]/div[1]/div[3]/aside/div/nav/ul/li[9]/a")
    WebElement fitness;

    @FindBy(xpath = "/html/body/div[5]/div[1]")
    WebElement pageBody;

    @FindBy(xpath = "//*[@id=\"google_ads_iframe_/120519536/AKC.Expert-Advice/home-living_0__container__\"]")
    WebElement topAdd;

    @FindBy(xpath = "//*[@id=\"newsletter-widget-side__title\"]")
    WebElement newsCase;

    @FindBy(xpath = "//*[@id=\"google_ads_iframe_/120519536/AKC.Expert-Advice/home-living_1__container__\"]")
    WebElement bottompAdd;

    @FindBy(xpath = "//html/body/div[8]")
    WebElement HMfooter;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[3]/aside/div/nav/ul/li[6]/a")
    WebElement LSquizzMenu;

    @FindBy(css = "body > div:nth-child(7) > div.page-container > div.page-layout > main > div.content-card-grid > div > div > div:nth-child(3) > div > div.content-card__body > a")
    WebElement LSquizzSport;

    @FindBy(xpath = "/html/body/div[5]/div[1]/div[3]/main/div[2]/form/div/div[2]/div/label/span")
    WebElement editorPick;


    DriverHelper driverHelper;

    WebDriver driver;

    // Constructor
    public ExpertAdvice(WebDriver _driver){
        this.driver = _driver;
        PageFactory.initElements(driver,this);
    }


    public void VerifyExpAdv(){

        this.menuexpadv.click();
        this.artexpadv.isDisplayed();
        this.allcateg.isDisplayed();
        this.dogbreeding.isDisplayed();
        this.grooming.isDisplayed();
        this.health.isDisplayed();
        this.homeliving.isDisplayed();
        this.lifestyle.isDisplayed();
        this.news.isDisplayed();
        this.nutrition.isDisplayed();
        this.puppyinfo.isDisplayed();
        this.sports.isDisplayed();
        this.training.isDisplayed();
        this.vetcorner.isDisplayed();
        this.findmatch.isDisplayed();
        this.dognamefind.isDisplayed();
        this.candogeat.isDisplayed();
        this.akctv.isDisplayed();
        this.akcmag.isDisplayed();
        this.newsletter.isDisplayed();
        this.presscenter.isDisplayed();
        this.akcdetection.isDisplayed();
        this.akccanine.isDisplayed();
        this.government.isDisplayed();
        this.akceducation.isDisplayed();
        this.akclibrary.isDisplayed();
    }


    //Click methods for expertAdvice Menu tabs


    public void Clickartexpadv() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        this.artexpadv.isDisplayed();
        this.artexpadv.click();
        this.artexpadvElement.isDisplayed();

    }

    public void Clickallcateg() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[1]/ul/li[1]/a")));
        this.allcateg.isDisplayed();
        this.allcateg.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.allcategElement.isDisplayed();

    }

    public void Clickdogbreeding() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[1]/ul/li[2]/a")));
        this.dogbreeding.isDisplayed();
        this.dogbreeding.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.dogbreedingElement.isDisplayed();

    }

    public void Clickgrooming() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(2) > div > div > div:nth-child(1) > ul > li:nth-child(3) > a")));
        this.grooming.isDisplayed();
        this.grooming.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.groomingElement.isDisplayed();

    }

    public void Clickhealth() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[1]/ul/li[4]/a")));
        this.health.isDisplayed();
        this.health.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.healthElement.isDisplayed();

    }

    public void Clickhomeliving() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[1]/ul/li[5]/a")));
        this.homeliving.isDisplayed();
        this.homeliving.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.homelivingElement.isDisplayed();

    }

    public void Clicklifestyle() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(2) > div > div > div:nth-child(1) > ul > li:nth-child(6) > a")));
        this.lifestyle.isDisplayed();
        this.lifestyle.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.lifestyleElement.isDisplayed();

    }

    public void Clicknews() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(2) > div > div > div:nth-child(2) > ul > li:nth-child(1) > a")));
        this.news.isDisplayed();
        this.news.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.newsElement.isDisplayed();

    }

    public void Clicknutrition() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[2]/a")));
        this.nutrition.isDisplayed();
        this.nutrition.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.nutritionElement.isDisplayed();

    }

    public void Clickpuppyinfo() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[3]/a")));
        this.puppyinfo.isDisplayed();
        this.puppyinfo.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.puppyinfoElement.isDisplayed();

    }

    public void Clicksports() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[4]/a")));
        this.sports.isDisplayed();
        this.sports.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.sportsElement.isDisplayed();

    }

    public void Clicktraining() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[5]/a")));
        this.training.isDisplayed();
        this.training.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.trainingElement.isDisplayed();

    }

    public void Clickvetcorner() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[2]/div/div/div[2]/ul/li[6]/a")));
        this.vetcorner.isDisplayed();
        this.vetcorner.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.vetcornerElement.isDisplayed();

    }

    public void ClickfindmatchOnExpAdvMenu() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[3]/div/div/div/ul/li[1]/a/div")));
        this.findmatch.isDisplayed();
        this.findmatch.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.findmatchElement.isDisplayed();

    }

    public void Clickdognamefind() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[3]/div/div/div/ul/li[2]/a/div")));
        this.dognamefind.isDisplayed();
        this.dognamefind.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.dognamefindElement.isDisplayed();

    }

    public void Clickcandogeat() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[3]/div/div/div/ul/li[3]/a/div")));
        this.candogeat.isDisplayed();
        this.candogeat.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.candogeatElement.isDisplayed();

    }

    public void Clickakctv() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"expert-advice\"]/div[4]/div/div/div/ul/li[1]/a")));
        this.akctv.isDisplayed();
        this.akctv.click();
        for (String winHandle : driver.getWindowHandles()) driver.switchTo().window(winHandle);
        final Boolean until = wait.until(ExpectedConditions.urlToBe("https://akc.tv/"));

    }

    public void Clickakcmag() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(2) > a")));
        this.akcmag.isDisplayed();
        this.akcmag.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.akcmagElement.isDisplayed();

    }

    public void Clicknewsletter() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(3) > a")));
        this.newsletter.isDisplayed();
        this.newsletter.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.newsletterElement.isDisplayed();

    }

    public void Clickpresscenter() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(4) > a")));
        this.presscenter.isDisplayed();
        this.presscenter.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.presscenterElement.isDisplayed();

    }

    public void Clickakcdetection() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(5) > a")));
        this.akcdetection.isDisplayed();
        this.akcdetection.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.akcdetectionElement.isDisplayed();

    }

    public void Clickakccanine() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(6) > a")));
        this.akccanine.isDisplayed();
        this.akccanine.click();
        for (String winHandle : driver.getWindowHandles()) driver.switchTo().window(winHandle);
        final Boolean until = wait.until(ExpectedConditions.urlContains("https://www.caninecollege.akc.org/"));

    }

    public void Clickgovernment() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(7) > a")));
        this.government.isDisplayed();
        this.government.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.governmentElement.isDisplayed();

    }

    public void Clickakceducation() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(8) > a")));
        this.akceducation.isDisplayed();
        this.akceducation.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.akceducationElement.isDisplayed();

    }

    public void Clickakclibrary() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(4) > div > div > div > ul > li:nth-child(9) > a")));
        this.akclibrary.isDisplayed();
        this.akclibrary.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.akclibraryElement.isDisplayed();

    }


    //Articles methods >


    public void allcategArticle() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        this.allcateg.isDisplayed();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(512, 168);");
        this.allcateg.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.allcategBox1.isDisplayed();
        this.allcategBox1.click();
        driver.navigate().to("https://www.akc.org/expert-advice/");

    }

    public void dogbreedArticle() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        this.dogbreeding.isDisplayed();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(512, 136);");
        this.dogbreeding.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.VideosBox.isDisplayed();
        this.VideosBox.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.urlToBe("https://www.akc.org/expert-advice/dog-breeding/?article_media_type%5B%5D=videos"));


    }

    public void healthArticle() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        this.health.isDisplayed();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(512, 68);");
        this.health.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.mediatitle.isDisplayed();
        this.fitness.isDisplayed();

    }

    public void newsArticle() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        this.news.isDisplayed();
        this.news.click();
        sleep(1000);
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.editorPick.isDisplayed();
        this.editorPick.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.urlToBe("https://www.akc.org/expert-advice/news/?editor_pick%5B%5D=editor-pick"));

    }

    public void HomelivingArticle() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        this.homeliving.isDisplayed();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(2) > div > div > div:nth-child(1) > ul > li:nth-child(5) > a")));
        this.homeliving.click();
        this.topAdd.isDisplayed();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.newsCase.isDisplayed();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0, 3000);");
        this.bottompAdd.isDisplayed();
        this.HMfooter.isDisplayed();

    }

    public void lifestyleArticle() throws InterruptedException {

        this.menuexpadv.click();
        sleep(1000);
        this.lifestyle.isDisplayed();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#expert-advice > div:nth-child(2) > div > div > div:nth-child(1) > ul > li:nth-child(6) > a")));
        this.lifestyle.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        sleep(1000);
        this.LSquizzMenu.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0, 3000);");
        this.LSquizzSport.isDisplayed();

    }

}
