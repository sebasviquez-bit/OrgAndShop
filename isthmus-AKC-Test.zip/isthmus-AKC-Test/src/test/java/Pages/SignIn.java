package Pages;

import Helpers.DataHelper;
import Model.User;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignIn {


    @FindBy(xpath = "//html/body/div[2]/div[2]/div[2]/div/form/div[1]/div[3]/input")
    WebElement userName;


    @FindBy(xpath = "//html/body/div[2]/div[2]/div[2]/div/form/div[1]/div[4]/input")
    WebElement password;


    @FindBy(css = "#gigya-login-form > div:nth-child(3) > div > input")
    WebElement ingresar;


    @FindBy(css = "#site-header > div > div.desktop-header > div > div.utility-header > nav.utility-nav.sign-in-nav > a")
    WebElement iconsignin;

    @FindBy(xpath = ("//html/body/div[2]/div/div[1]/div/div[1]/nav[2]/div/a[1]"))
    WebElement myakc;

    @FindBy(xpath = ("//html/body/div[2]/div/div[1]/div/div[1]/nav[2]/div/a[2]"))
    WebElement logout;

    @FindBy(xpath = "//html/body/div[2]/div[2]/div[2]/div/form/div[1]/div[1]/div/div/table/tbody/tr/td/center/table/tbody/tr/td[2]/table/tbody/tr[1]/td/table/tbody/tr/td[2]/center/div/div/div")
    WebElement gigyabox;

    @FindBy(xpath = ("//html/body/div[2]/div[2]/div[2]/div/form/div[1]/div[4]/label/span/a"))
    WebElement forgot;

    @FindBy(xpath = ("//html/body/div[2]/div[2]/div[2]/div/form/div[3]/label/a"))
    WebElement signup;

    @FindBy(xpath = "//html/body/div[2]/div[2]/div[2]/div/form/div[1]/h2")
    WebElement signinlogo;

    @FindBy(xpath = "//html/body/div[2]/div[2]/div[2]/div/form/div[1]/div[3]/label/span")
    WebElement otheroption;



    WebDriver driver;
    DataHelper dataHelper;



    public SignIn(WebDriver _driver){
        this.driver = _driver;
        PageFactory.initElements(driver,this);
    }

    public void signInUser(User _testUser) throws InterruptedException {

        this.iconsignin.click();
        this.gigyabox.isDisplayed();
        this.signup.isDisplayed();
        this.forgot.isDisplayed();
        this.signinlogo.isDisplayed();
        this.otheroption.isDisplayed();
        this.userName.sendKeys(_testUser.username);
        this.password.sendKeys(_testUser.password);
        this.ingresar.click();
        this.iconsignin.isDisplayed();
        this.myakc.isDisplayed();
        this.logout.isDisplayed();
        Actions action = new Actions(this.driver);
        action.moveToElement(iconsignin).perform();
        action.moveToElement(iconsignin).click();
        this.logout.click();
        this.iconsignin.isDisplayed();

    }




}
