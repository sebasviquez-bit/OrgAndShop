package Pages;
import Helpers.DriverHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BreedSelector {

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[1]")
    WebElement breedsmenu;

    @FindBy(xpath = "//*[@id=\"dog-breeds\"]/div[2]/div/div/div/ul/li[1]/a/div")
    WebElement findmatch;

    @FindBy(xpath = "//*[@id=\"get-started\"]")
    WebElement getstarted;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[1]/div[1]/h4")
    WebElement headbreedsel1;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[1]/img[1]")
    WebElement imagepage1;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[1]/div[2]/div[1]/label/span")
    WebElement newtodogs;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[1]/div[2]/div[1]/div")
    WebElement newtodogslab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[1]/div[2]/div[2]/label/span")
    WebElement currentowndog;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[1]/div[2]/div[2]/div")
    WebElement currentowndoglab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[1]/div[2]/div[3]/label/span")
    WebElement owndogpast;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[1]/div[2]/div[3]/div")
    WebElement owndogpastlab;

    @FindBy(xpath = "//*[@id=\"experience-continue\"]")
    WebElement continue1;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[3]/div[1]/h4")
    WebElement headbreedsel2;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[3]/img[1]")
    WebElement imagepage2;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[3]/div[2]/div[1]/label/span")
    WebElement apartment;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[3]/div[2]/div[1]/div")
    WebElement apartmentlab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[3]/div[2]/div[2]/label/span")
    WebElement housesmall;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[3]/div[2]/div[2]/div")
    WebElement housesmalllab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[3]/div[2]/div[3]/label/span")
    WebElement houselarge;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[3]/div[2]/div[3]/div")
    WebElement houselargelab;

    @FindBy(xpath = "//*[@id=\"home-type-continue\"]")
    WebElement continue2;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[4]/div[1]/h4")
    WebElement headbreedsel3;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[4]/img[1]")
    WebElement imagepage3;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[4]/div[2]/div[1]/label/span")
    WebElement yes;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[4]/div[2]/div[1]/div")
    WebElement yeslab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[4]/div[2]/div[2]/label/span")
    WebElement no;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[4]/div[2]/div[2]/div")
    WebElement nolab;

    @FindBy(xpath = "//*[@id=\"apartments-continue\"]")
    WebElement continue3;

    @FindBy(xpath = "/html/body/div[7]/div/div/div[2]/main/div[4]/div[5]/div[1]/h4")
    WebElement headbreedsel4;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[5]/img[1]")
    WebElement imagepage4;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[5]/div[2]/div[1]/label/span")
    WebElement yes2;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[5]/div[2]/div[1]/div")
    WebElement yes2lab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[5]/div[2]/div[2]/label/span")
    WebElement no2;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[5]/div[2]/div[2]/div")
    WebElement no2lab;

    @FindBy(xpath = "//*[@id=\"children-continue\"]")
    WebElement continue4;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[6]/div[1]/h4")
    WebElement headbreedsel5;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[6]/img[1]")
    WebElement imagepage5;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[6]/div[2]/div/div[1]")
    WebElement onlybarks;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[6]/div[2]/div/div[3]")
    WebElement likesvocal;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[6]/div[2]/div/div[2]/div/a[1]/div")
    WebElement minusbark;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[6]/div[2]/div/div[2]/div/a[2]/div")
    WebElement plusbark;

    @FindBy(xpath = "//*[@id=\"volume-continue\"]")
    WebElement continue5;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[7]/div[1]/h4")
    WebElement headbreedsel6;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[7]/img[1]")
    WebElement imagepage6;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[7]/div[2]/div[1]/label/span")
    WebElement infreq;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[7]/div[2]/div[1]/div")
    WebElement infreqlab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[7]/div[2]/div[2]/label/span")
    WebElement freq;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[7]/div[2]/div[2]/div")
    WebElement freqlab;

    @FindBy(xpath = "//*[@id=\"shedding-continue\"]")
    WebElement continue6;

    @FindBy(xpath = "//html/body/div[6]/div[2]/div/div[3]/h2")
    WebElement headresults;

    @FindBy(xpath = "//html/body/div[6]/div[2]/div/div[4]/div[1]/img")
    WebElement imageresults;

    @FindBy(xpath = "//html/body/div[6]/div[2]/div/div[4]/div[2]")
    WebElement results;

    @FindBy(xpath = "//html/body/div[6]/div[2]/div/div[4]/div[1]/div[1]")
    WebElement resultsdetail;

    @FindBy(xpath = "//html/body/div[6]/div[2]/div/div[4]/div[1]/div[3]/a[1]")
    WebElement findpuppies;

    @FindBy(xpath = "//html/body/div[6]/div[2]/div/div[4]/div[1]/div[3]/a[2]")
    WebElement learnmore;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[1]/h2")
    WebElement restmatch;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[1]/p")
    WebElement restmatchdet;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[2]/div[2]")
    WebElement match2;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[2]/div[1]/img")
    WebElement match2pict;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[3]/div[2]")
    WebElement match3;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[3]/div[1]/img")
    WebElement match3pict;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[4]/div[2]")
    WebElement match4;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[4]/div[1]/img")
    WebElement match4pict;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[5]/div[2]")
    WebElement match5;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[5]/div[1]/img")
    WebElement match5pict;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[6]/div[2]")
    WebElement match6;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[6]/div[1]/img")
    WebElement match6pict;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[7]/div[2]")
    WebElement match7;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[7]/div[1]/img")
    WebElement match7pict;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[8]/div[2]")
    WebElement match8;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[8]/div[1]/img")
    WebElement match8pict;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[9]/div[2]")
    WebElement match9;

    @FindBy(xpath = "//html/body/div[6]/div[3]/div/div/div[9]/div[1]/img")
    WebElement match9pict;

    @FindBy(xpath = "//html/body/div[6]/div[4]/div/div/main/div[3]/h2")
    WebElement breedcomp;

    @FindBy(xpath = "//html/body/div[6]/div[4]/div/div/main")
    WebElement breedcompdetail;

    @FindBy(xpath = "//html/body/div[6]/div[5]/div/div/a")
    WebElement quizagain;

    @FindBy(xpath = "//html/body/div[6]/div[5]/div/div/div")
    WebElement sharequiz;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[2]/div[1]/h4")
    WebElement timeheadersel;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[2]/img[1]")
    WebElement timeheaderpict;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[1]/label/span")
    WebElement littletime;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[1]/div")
    WebElement littletimelab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/label/span")
    WebElement sometime;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div")
    WebElement sometimelab;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[3]/label/span")
    WebElement alotoftime;

    @FindBy(xpath = "//html/body/div[7]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[3]/div")
    WebElement alotoftimelab;

    @FindBy(xpath = "//*[@id=\"training-continue\"]")
    WebElement continue7;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[8]/div[1]/h4")
    WebElement actlevelheader;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[8]/img[1]")
    WebElement actlevelpict;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[8]/div[2]/div[1]/label/span")
    WebElement hangcouch;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[8]/div[2]/div[1]/div")
    WebElement hangcouchlab;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[8]/div[2]/div[2]/label/span")
    WebElement walkaround;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[8]/div[2]/div[2]/div")
    WebElement walkaroundlab;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[8]/div[2]/div[3]/label/span")
    WebElement goingadv;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[4]/div[8]/div[2]/div[3]/div")
    WebElement goingadvlab;

    @FindBy(xpath = "//*[@id=\"activity-level-continue\"]")
    WebElement continue8;


    DriverHelper driverHelper;

    WebDriver driver;

    // Constructor
    public BreedSelector(WebDriver _driver){
        this.driver = _driver;
        PageFactory.initElements(driver,this);
    }


    public void VerifyBreedSelector1(){

        this.breedsmenu.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"dog-breeds\"]/div[2]/div/div/div/ul/li[1]/a/div")));
        this.findmatch.isDisplayed();
        this.findmatch.click();
        this.getstarted.isDisplayed();
        this.getstarted.click();
        this.headbreedsel1.isDisplayed();
        this.imagepage1.isDisplayed();
        this.newtodogs.isDisplayed();
        this.newtodogslab.isDisplayed();
        this.currentowndog.isDisplayed();
        this.currentowndoglab.isDisplayed();
        this.owndogpast.isDisplayed();
        this.owndogpastlab.isDisplayed();
        this.newtodogs.click();
        this.continue1.click();
        this.headbreedsel2.isDisplayed();
        this.imagepage2.isDisplayed();
        this.apartment.isDisplayed();
        this.apartmentlab.isDisplayed();
        this.housesmall.isDisplayed();
        this.housesmalllab.isDisplayed();
        this.houselarge.isDisplayed();
        this.houselargelab.isDisplayed();
        this.apartment.click();
        this.continue2.click();
        this.headbreedsel3.isDisplayed();
        this.imagepage3.isDisplayed();
        this.yes.isDisplayed();
        this.yeslab.isDisplayed();
        this.no.isDisplayed();
        this.nolab.isDisplayed();
        this.yes.click();
        this.continue3.click();
        this.headbreedsel4.isDisplayed();
        this.imagepage4.isDisplayed();
        this.yes2.isDisplayed();
        this.yes2lab.isDisplayed();
        this.no2.isDisplayed();
        this.no2lab.isDisplayed();
        this.yes2.click();
        this.continue4.click();
        this.headbreedsel5.isDisplayed();
        this.imagepage5.isDisplayed();
        this.onlybarks.isDisplayed();
        this.likesvocal.isDisplayed();
        this.minusbark.isDisplayed();
        this.plusbark.isDisplayed();
        this.plusbark.click();
        this.plusbark.click();
        this.continue5.click();
        this.headbreedsel6.isDisplayed();
        this.imagepage6.isDisplayed();
        this.infreq.isDisplayed();
        this.infreqlab.isDisplayed();
        this.freq.isDisplayed();
        this.freqlab.isDisplayed();
        this.infreq.click();
        this.continue6.click();
        this.actlevelheader.isDisplayed();
        this.actlevelpict.isDisplayed();
        this.hangcouch.isDisplayed();
        this.hangcouchlab.isDisplayed();
        this.walkaround.isDisplayed();
        this.walkaroundlab.isDisplayed();
        this.goingadv.isDisplayed();
        this.goingadvlab.isDisplayed();
        this.hangcouch.click();
        this.continue8.click();
        this.headresults.isDisplayed();
        this.imageresults.isDisplayed();
        this.results.isDisplayed();
        this.resultsdetail.isDisplayed();
        this.findpuppies.isDisplayed();
        this.learnmore.isDisplayed();
        this.restmatch.isDisplayed();
        this.restmatchdet.isDisplayed();
        this.match2.isDisplayed();
        this.match2pict.isDisplayed();
        this.match3.isDisplayed();
        this.match3pict.isDisplayed();
        this.match4.isDisplayed();
        this.match4pict.isDisplayed();
        this.match5.isDisplayed();
        this.match5pict.isDisplayed();
        this.match6.isDisplayed();
        this.match6pict.isDisplayed();
        this.match7.isDisplayed();
        this.match7pict.isDisplayed();
        this.match8.isDisplayed();
        this.match8pict.isDisplayed();
        this.match9.isDisplayed();
        this.match9pict.isDisplayed();
        this.breedcomp.isDisplayed();
        this.breedcompdetail.isDisplayed();
        this.quizagain.isDisplayed();
        this.sharequiz.isDisplayed();


    }

    public void VerifyBreedSelector2(){

        this.breedsmenu.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"dog-breeds\"]/div[2]/div/div/div/ul/li[1]/a/div")));
        this.findmatch.isDisplayed();
        this.findmatch.click();
        this.getstarted.click();
        this.currentowndog.click();
        this.continue1.click();
        this.timeheadersel.isDisplayed();
        this.timeheaderpict.isDisplayed();
        this.littletime.isDisplayed();
        this.littletimelab.isDisplayed();
        this.sometime.isDisplayed();
        this.sometimelab.isDisplayed();
        this.alotoftime.isDisplayed();
        this.alotoftimelab.isDisplayed();
        this.littletime.click();
        this.continue7.click();
        this.housesmall.click();
        this.continue2.click();
        this.headresults.isDisplayed();
        this.imageresults.isDisplayed();
        this.results.isDisplayed();
        this.resultsdetail.isDisplayed();
        this.findpuppies.isDisplayed();
        this.learnmore.isDisplayed();
        this.restmatch.isDisplayed();
        this.restmatchdet.isDisplayed();
        this.match2.isDisplayed();
        this.match2pict.isDisplayed();
        this.match3.isDisplayed();
        this.match3pict.isDisplayed();
        this.match4.isDisplayed();
        this.match4pict.isDisplayed();
        this.match5.isDisplayed();
        this.match5pict.isDisplayed();
        this.match6.isDisplayed();
        this.match6pict.isDisplayed();
        this.match7.isDisplayed();
        this.match7pict.isDisplayed();
        this.match8.isDisplayed();
        this.match8pict.isDisplayed();
        //this.match9.isDisplayed();
        //this.match9pict.isDisplayed();
        this.breedcomp.isDisplayed();
        this.breedcompdetail.isDisplayed();
        this.quizagain.isDisplayed();
        this.sharequiz.isDisplayed();

    }


    public void VerifyBreedSelector3(){


        this.breedsmenu.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"dog-breeds\"]/div[2]/div/div/div/ul/li[1]/a/div")));
        this.findmatch.isDisplayed();
        this.findmatch.click();
        this.getstarted.click();
        this.owndogpast.click();
        this.continue1.click();
        this.sometime.click();
        this.continue7.click();
        this.houselarge.click();
        this.continue2.click();
        this.no2.click();
        this.continue4.click();
        this.plusbark.click();
        this.plusbark.click();
        this.plusbark.click();
        this.plusbark.click();
        this.plusbark.click();
        this.continue5.click();
        this.freq.click();
        this.continue6.click();
        this.actlevelheader.isDisplayed();
        this.actlevelpict.isDisplayed();
        this.hangcouch.isDisplayed();
        this.hangcouchlab.isDisplayed();
        this.walkaround.isDisplayed();
        this.walkaroundlab.isDisplayed();
        this.goingadv.isDisplayed();
        this.goingadvlab.isDisplayed();
        this.hangcouch.click();
        this.continue8.click();
        this.headresults.isDisplayed();
        this.imageresults.isDisplayed();
        this.results.isDisplayed();
        this.resultsdetail.isDisplayed();
        this.findpuppies.isDisplayed();
        this.learnmore.isDisplayed();
        this.restmatch.isDisplayed();
        this.restmatchdet.isDisplayed();
        this.match2.isDisplayed();
        this.match2pict.isDisplayed();
        this.match3.isDisplayed();
        this.match3pict.isDisplayed();
        this.match4.isDisplayed();
        this.match4pict.isDisplayed();
        this.match5.isDisplayed();
        this.match5pict.isDisplayed();
        this.match6.isDisplayed();
        this.match6pict.isDisplayed();
        this.match7.isDisplayed();
        this.match7pict.isDisplayed();
        this.match8.isDisplayed();
        this.match8pict.isDisplayed();
        //this.match9.isDisplayed();
        //this.match9pict.isDisplayed();
        //this.breedcomp.isDisplayed();
        //this.breedcompdetail.isDisplayed();
        //this.quizagain.isDisplayed();
        //this.sharequiz.isDisplayed();


    }











}
