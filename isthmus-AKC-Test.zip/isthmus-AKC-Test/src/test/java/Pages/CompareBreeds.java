package Pages;
import Helpers.DriverHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class CompareBreeds {

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[1]")
    WebElement breeds;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[2]/div/div/div/ul/li[2]/a/div")
    WebElement breedscompa;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[3]/div")
    WebElement breedscompmessage;

    @FindBy(xpath = "//html/body/div[6]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[1]/div[2]/div[1]/img")
    WebElement select1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]")
    WebElement affens;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/img")
    WebElement affenspic;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[2]/div[2]/div[1]/img")
    WebElement select2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[2]/div[2]/div[2]/div[2]/div[4]")
    WebElement akita;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[2]/div[1]/div[2]/div[2]/img")
    WebElement akitapic;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[3]/div[2]/div[1]/img")
    WebElement select3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[3]/div[2]/div[2]/div[2]/div[19]")
    WebElement beagle;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[3]/div[1]/div[2]/div[2]/img")
    WebElement beaglepic;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[4]/div[2]/div[1]/img")
    WebElement select4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[4]/div[2]/div[2]/div[2]/div[40]")
    WebElement boxer;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[4]/div[1]/div[2]/div[2]/img")
    WebElement boxerpic;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[5]/div[2]/div[1]/img")
    WebElement select5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[5]/div[2]/div[2]/div[2]/div[45]")
    WebElement bullterrier;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[1]/div[5]/div[1]/div[2]/div[2]/img")
    WebElement bullterrierpic;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[5]/a")
    WebElement breedcompbutton;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[3]")
    WebElement personality;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[5]/div[1]/span")
    WebElement perso1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[5]/div[2]/span")
    WebElement perso2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[5]/div[3]/span")
    WebElement perso3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[5]/div[4]/span")
    WebElement perso4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[5]/div[5]/span")
    WebElement perso5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[6]")
    WebElement poprank;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[8]/div[1]")
    WebElement poprank1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[8]/div[2]")
    WebElement poprank2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[8]/div[3]")
    WebElement poprank3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[8]/div[4]")
    WebElement poprank4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[8]/div[5]")
    WebElement poprank5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[9]")
    WebElement group;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[11]/div[1]/a")
    WebElement group1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[11]/div[2]/a")
    WebElement group2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[11]/div[3]/a")
    WebElement group3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[11]/div[4]/a")
    WebElement group4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[11]/div[5]/a")
    WebElement group5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[12]")
    WebElement size;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[14]/div[1]")
    WebElement size1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[14]/div[2]")
    WebElement size2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[14]/div[3]")
    WebElement size3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[14]/div[4]")
    WebElement size4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[14]/div[5]")
    WebElement size5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[15]")
    WebElement lifexp;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[17]/div[1]")
    WebElement lifexp1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[17]/div[2]")
    WebElement lifexp2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[17]/div[3]")
    WebElement lifexp3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[17]/div[4]")
    WebElement lifexp4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[17]/div[5]")
    WebElement lifexp5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[18]")
    WebElement charac;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[20]/div[1]")
    WebElement charac1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[20]/div[2]")
    WebElement charac2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[20]/div[3]")
    WebElement charac3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[20]/div[4]")
    WebElement charac4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[20]/div[5]")
    WebElement charac5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[21]")
    WebElement trainab;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[23]/div[1]")
    WebElement trainab1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[23]/div[2]")
    WebElement trainab2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[23]/div[3]")
    WebElement trainab3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[23]/div[4]")
    WebElement trainab4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[23]/div[5]")
    WebElement trainab5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[24]")
    WebElement coatlength;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[26]/div[1]")
    WebElement coatlength1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[26]/div[2]")
    WebElement coatlength2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[26]/div[3]")
    WebElement coatlength3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[26]/div[4]")
    WebElement coatlength4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[26]/div[5]")
    WebElement coatlength5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[27]")
    WebElement groom;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[29]/div[1]")
    WebElement groom1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[29]/div[2]")
    WebElement groom2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[29]/div[3]")
    WebElement groom3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[29]/div[4]")
    WebElement groom4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[29]/div[5]")
    WebElement groom5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[30]")
    WebElement shedd;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[32]/div[1]")
    WebElement shedd1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[32]/div[2]")
    WebElement shedd2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[32]/div[3]")
    WebElement shedd3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[32]/div[4]")
    WebElement shedd4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[32]/div[5]")
    WebElement shedd5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[33]")
    WebElement actlev;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[35]/div[1]")
    WebElement actlev1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[35]/div[2]")
    WebElement actlev2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[35]/div[3]")
    WebElement actlev3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[35]/div[4]")
    WebElement actlev4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[35]/div[5]")
    WebElement actlev5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[36]")
    WebElement barking;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[38]/div[1]")
    WebElement barking1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[38]/div[2]")
    WebElement barking2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[38]/div[3]")
    WebElement barking3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[38]/div[4]")
    WebElement barking4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[38]/div[5]")
    WebElement barking5;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[39]/div[1]/a")
    WebElement findpuppy1;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[39]/div[2]/a")
    WebElement findpuppy2;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[39]/div[3]/a")
    WebElement findpuppy3;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[39]/div[4]/a")
    WebElement findpuppy4;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[4]/div[2]/div[2]/div[2]/div/div/div[39]/div[5]/a")
    WebElement findpuppy5;

    DriverHelper driverHelper;

    WebDriver driver;

    // Constructor
    public CompareBreeds(WebDriver _driver) {
        this.driver = _driver;
        PageFactory.initElements(driver, this);

    }

    public void VerifyCompareBreeds(){

        this.breeds.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//html/body/div[2]/div/div[2]/div[1]/div[2]/div/div/div/ul/li[2]/a/div")));
        this.breedscompa.isDisplayed();
        this.breedscompa.click();
        //this.breedscompmessage.isDisplayed();
        this.select1.isDisplayed();
        this.select1.click();
        this.affens.click();
        this.affenspic.isDisplayed();
        this.select2.click();
        this.akita.click();
        this.akitapic.isDisplayed();
        this.select3.click();
        this.beagle.click();
        this.beaglepic.isDisplayed();
        this.select4.click();
        this.boxer.click();
        this.boxerpic.isDisplayed();
        this.select5.click();
        this.bullterrier.click();
        this.bullterrierpic.isDisplayed();
        this.breedcompbutton.click();
        this.personality.isDisplayed();
        this.perso1.isDisplayed();
        this.perso2.isDisplayed();
        this.perso3.isDisplayed();
        this.perso4.isDisplayed();
        this.perso5.isDisplayed();
        this.poprank.isDisplayed();
        this.poprank1.isDisplayed();
        this.poprank2.isDisplayed();
        this.poprank3.isDisplayed();
        this.poprank4.isDisplayed();
        this.poprank5.isDisplayed();
        this.group.isDisplayed();
        this.group1.isDisplayed();
        this.group2.isDisplayed();
        this.group3.isDisplayed();
        this.group4.isDisplayed();
        this.group5.isDisplayed();
        this.size.isDisplayed();
        this.size1.isDisplayed();
        this.size2.isDisplayed();
        this.size3.isDisplayed();
        this.size4.isDisplayed();
        this.size5.isDisplayed();
        this.lifexp.isDisplayed();
        this.lifexp1.isDisplayed();
        this.lifexp2.isDisplayed();
        this.lifexp3.isDisplayed();
        this.lifexp4.isDisplayed();
        this.lifexp5.isDisplayed();
        this.charac.isDisplayed();
        this.charac1.isDisplayed();
        this.charac2.isDisplayed();
        this.charac3.isDisplayed();
        this.charac4.isDisplayed();
        this.charac5.isDisplayed();
        this.trainab.isDisplayed();
        this.trainab1.isDisplayed();
        this.trainab2.isDisplayed();
        this.trainab3.isDisplayed();
        this.trainab4.isDisplayed();
        this.trainab5.isDisplayed();
        this.coatlength.isDisplayed();
        this.coatlength1.isDisplayed();
        this.coatlength2.isDisplayed();
        this.coatlength3.isDisplayed();
        this.coatlength4.isDisplayed();
        this.coatlength5.isDisplayed();
        this.groom.isDisplayed();
        this.groom1.isDisplayed();
        this.groom2.isDisplayed();
        this.groom3.isDisplayed();
        this.groom4.isDisplayed();
        this.groom5.isDisplayed();
        this.shedd.isDisplayed();
        this.shedd1.isDisplayed();
        this.shedd2.isDisplayed();
        this.shedd3.isDisplayed();
        this.shedd4.isDisplayed();
        this.shedd5.isDisplayed();
        this.actlev.isDisplayed();
        this.actlev1.isDisplayed();
        this.actlev2.isDisplayed();
        this.actlev3.isDisplayed();
        this.actlev4.isDisplayed();
        this.actlev5.isDisplayed();
        this.barking.isDisplayed();
        this.barking1.isDisplayed();
        this.barking2.isDisplayed();
        this.barking3.isDisplayed();
        this.barking4.isDisplayed();
        this.barking5.isDisplayed();
        this.findpuppy1.isDisplayed();
        this.findpuppy2.isDisplayed();
        this.findpuppy3.isDisplayed();
        this.findpuppy4.isDisplayed();
        this.findpuppy5.isDisplayed();


    }





}
