package Pages;
import Helpers.DataHelper;
import Model.Word;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Search {

    @FindBy(xpath = "//*[@id='desktop-search']")
    WebElement search;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[1]/div/div/div[1]/form/button/svg")
    WebElement searchbutton;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[2]/div/div[2]/form/button")
    WebElement search2;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[1]/div/div/div[1]/form/button/svg/g/ellipse")
    WebElement searchbutton2;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[4]/main/div[1]/h3")
    WebElement numresults;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[4]/main/div[1]/div")
    WebElement items;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[4]/aside/div/div[1]/form/div[2]/div/div")
    WebElement sections;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[4]/main/div[3]/div/div[1]/a/div/img")
    WebElement resultsimg;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[4]/main/div[3]/div/div[1]/div/a")
    WebElement firstresult;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[4]/main/div[3]/div/div[1]/div/div")
    WebElement frbody;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[4]/main")
    WebElement listresults;

    @FindBy(xpath = "//html/body/div[4]/div[1]/div[4]/main/div[4]/div")
    WebElement navigate;


    WebDriver driver;
    DataHelper dataHelper;


    public Search(WebDriver _driver) {
        this.driver = _driver;
        PageFactory.initElements(driver, this);


    }

    public void SearchPage(Word _searchword) throws InterruptedException {

        this.search.sendKeys(_searchword.WordSearch);
        this.search.sendKeys(Keys.RETURN);
        //this.searchbutton2.click();
        this.items.isDisplayed();
        this.numresults.isDisplayed();
        this.sections.isDisplayed();
        this.resultsimg.isDisplayed();
        this.firstresult.isDisplayed();
        this.frbody.isDisplayed();
        this.listresults.isDisplayed();
        this.navigate.isDisplayed();

    }
}
