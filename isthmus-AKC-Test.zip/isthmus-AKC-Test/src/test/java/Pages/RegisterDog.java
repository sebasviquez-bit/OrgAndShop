package Pages;

import Helpers.DriverHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegisterDog {

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[1]/nav[1]/a[3]")
    WebElement register;

    @FindBy(xpath = "//html/body/div[4]/div/div[3]/img")
    WebElement registerimg;

    @FindBy(xpath = "//html/body/div[4]/div/div[3]/div/span")
    WebElement online;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/aside/div/nav/ul/li[1]/a")
    WebElement regdog;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/aside/div/nav/ul/li[2]/a")
    WebElement reglitt;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[1]/label/span")
    WebElement regalit;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[1]/label/div/span[1]")
    WebElement regalittext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[1]/label/span")
    WebElement mylitt;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[1]/label/div/span[1]")
    WebElement mylitttext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[3]/div[1]/label/span")
    WebElement breezreg;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[1]/label/span")
    WebElement damsire;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[1]/label/div/span")
    WebElement damsiretext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[2]/label/span")
    WebElement onlydam;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[2]/label/div/span[1]")
    WebElement onlydamtext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[3]/label/span")
    WebElement onlysire;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[3]/label/div/span[1]")
    WebElement onlysiretext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]/div[1]/label/span")
    WebElement fresh;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]/div[1]/label/div/span")
    WebElement freshtext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]/div[2]/label/span")
    WebElement freshext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]/div[2]/label/div/span")
    WebElement freshexttext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]/div[3]/label/span")
    WebElement froze;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]/div[3]/label/div/span")
    WebElement frozetext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]/div[4]/label/span")
    WebElement special;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]/div[4]/label/div/span")
    WebElement specialtext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[3]/div[2]/div[1]/label/span")
    WebElement ezregopt;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[3]/div[2]/div[1]/label/div/span[1]")
    WebElement ezregopttext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[3]/div[2]/div[2]/label/span")
    WebElement puppyman;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[3]/div[2]/div[2]/label/div/span[1]")
    WebElement puppymantext;





    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/aside/div/nav/ul/li[3]/a")
    WebElement transown;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/aside/div/nav/ul/li[4]/a")
    WebElement purcped;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/aside/div/nav/ul/li[5]/a")
    WebElement moreinfo;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/div[1]/div/div/h1")
    WebElement registra;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/div[2]/div")
    WebElement bodyd;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/div[2]/div/p[5]/a")
    WebElement startdog;

   @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[1]/label/span")
    WebElement regpure;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[1]/label/div/span[1]")
    WebElement regpuretext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[1]/label/div/span[2]/a")
    WebElement checkreg;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[1]/label/span")
    WebElement enrolldog;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[1]/label/div/span[1]")
    WebElement enrolldogtext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[3]/div[1]/label/span")
    WebElement enrollpure;


    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[3]/div[1]/label/div/span[1]")
    WebElement enrollpuretext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[1]/label/span")
    WebElement other;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[1]/label/div/span[1]")
    WebElement othertext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[1]/label/span")
    WebElement ownlitt;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[1]/label/div/span[1]")
    WebElement ownlitttext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[2]/label/span")
    WebElement newown;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[2]/label/div/span[1]")
    WebElement newowntext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[3]/label/span")
    WebElement prepaid;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[1]/div[2]/div[3]/label/div/span[1]")
    WebElement prepaidtext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[2]")
    WebElement joincantext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[3]/div[2]")
    WebElement akcpal;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[2]/div[1]/label/span")
    WebElement foreigreg;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[2]/div[1]/label/div/span[1]")
    WebElement foreigregtext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[2]/div[2]/label/span")
    WebElement fundstock;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[2]/div[2]/label/div/span[1]")
    WebElement fundstocktext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[2]/div[3]/label/span")
    WebElement openreg;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[2]/div[3]/label/div/span[1]")
    WebElement openregtext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[2]/div[4]/label/span")
    WebElement kenname;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/div[4]/div[2]/div[4]/label/div/span[1]")
    WebElement kennametext;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form")
    WebElement continuereg;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/form/a")
    WebElement buttoncont;

       @FindBy(xpath = "//html/body/div[5]/div/div/main/div[3]/div/div/div/div[3]/div/form/div/div[8]")
    WebElement regform1;

    @FindBy(xpath = "//html/body/div[6]/div/div/main/h1")
    WebElement regform2;

    @FindBy(xpath = "//html/body/div[4]/div/div/div/div[3]/div/form/div/h1")
    WebElement regform3;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/p[4]/iframe")
    WebElement regform4;

    @FindBy(xpath = "//*[@id=\"page-title\"]/div/h1")
    WebElement transownheader;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/div[2]/div")
    WebElement transownbody;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/div[2]/div/p[4]/a")
    WebElement transownbut;

    @FindBy(xpath = "//html/body/div[5]/div/div/main/div[2]/div/div[2]/app-root/main/div/app-login/div/div[2]/div/img")
    WebElement transownform;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[2]/div/div/h1")
    WebElement purcpedheader;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/p[3]")
    WebElement certped;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/p[4]/a")
    WebElement certpedbut;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/p[5]")
    WebElement onlinesear;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/p[6]/a")
    WebElement onlinesearbut;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[1]/span")
    WebElement dogregmenu;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[1]/span/span")
    WebElement dogregmenuexp;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[1]/div/ul")
    WebElement dogregmenubody;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[2]/span")
    WebElement littregmenu;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[2]/span/span")
    WebElement littregmenuexp;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[2]/div")
    WebElement littregmenubody;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[3]/span")
    WebElement feesched;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[3]/span/span")
    WebElement feeschedexp;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[3]/div")
    WebElement feeschedbody;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[4]/span")
    WebElement rulregmenu;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[4]/span/span")
    WebElement rulregmenuexp;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[4]/div")
    WebElement rulregmenubody;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[5]/span")
    WebElement dowforms;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[5]/span/span")
    WebElement dowformsexp;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/ul/li[5]/div/ul")
    WebElement dowformsbody;



    DriverHelper driverHelper;

    WebDriver driver;

    // Constructor
    public RegisterDog(WebDriver _driver) {
        this.driver = _driver;
        PageFactory.initElements(driver, this);


    }

    private void newWindow() {
        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.urlContains("https://www.apps.akc.org/"));
    }

    private void newWindow2() {
        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/register/information/"));
    }

    private void newWindow3() {
        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.urlContains("https://images.akc.org/pdf/"));
    }

    private void newWindow4() {
        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.urlContains("images.akc.org/pdf/"));
    }




    public void VerifyRegisterDog1(){

        this.register.click();
        this.driver.get(this.driver.getCurrentUrl()+"?test=true");
        this.registerimg.isDisplayed();
        this.online.isDisplayed();
        this.regdog.isDisplayed();
        this.reglitt.isDisplayed();
        this.transown.isDisplayed();
        this.purcped.isDisplayed();
        this.moreinfo.isDisplayed();
        this.regdog.click();
        this.regpure.isDisplayed();
        this.regpuretext.isDisplayed();
        this.checkreg.isDisplayed();
        this.enrolldog.isDisplayed();
        this.enrolldogtext.isDisplayed();
        this.enrollpure.isDisplayed();
        this.enrollpuretext.isDisplayed();
        this.registra.isDisplayed();
        this.bodyd.isDisplayed();
        //this.startdog.isDisplayed();
        this.other.isDisplayed();
        this.othertext.isDisplayed();
        this.regpure.click();
        this.ownlitt.isDisplayed();
        this.ownlitttext.isDisplayed();
        this.newown.isDisplayed();
        this.newowntext.isDisplayed();
        this.prepaid.isDisplayed();
        this.prepaidtext.isDisplayed();
        this.enrolldog.click();
        this.joincantext.isDisplayed();
        this.enrollpure.click();
        this.akcpal.isDisplayed();
        this.other.click();
        this.foreigreg.isDisplayed();
        this.foreigregtext.isDisplayed();
        this.fundstock.isDisplayed();
        this.fundstocktext.isDisplayed();
        this.openreg.isDisplayed();
        this.openregtext.isDisplayed();
        this.kenname.isDisplayed();
        this.kennametext.isDisplayed();
        this.buttoncont.isDisplayed();
        this.regpure.click();
        this.ownlitt.click();
        this.buttoncont.click();
        newWindow();
        //this.regform1.isDisplayed();

    }


    public void VerifyRegisterDog2(){

        this.register.click();
        this.regdog.click();
        this.regpure.click();
        this.newown.click();
        this.buttoncont.click();
        newWindow();
        this.regform2.isDisplayed();

    }

    public void VerifyRegisterDog3(){

        this.register.click();
        this.regdog.click();
        this.regpure.click();
        this.prepaid.click();
        this.buttoncont.click();
        newWindow();
        this.regform3.isDisplayed();

    }

    public void VerifyRegisterDog4(){

        this.register.click();
        this.regdog.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//html/body/div[4]/div/div[4]/div/main/form/div[2]/div[1]/label/span")));
        this.enrolldog.isDisplayed();
        this.enrolldog.click();
        this.buttoncont.click();
        newWindow2();
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0, 800);");
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("/html/body/div[5]/div/div[2]/main/div[3]/div/div/div/p[4]/iframe")));
        //this.regform4.isDisplayed();

    }

    public void VerifyRegisterDog6(){

        this.register.click();
        this.regdog.click();
        this.other.click();
        this.foreigreg.click();
        this.buttoncont.click();
        newWindow4();

    }

    public void VerifyRegisterDog7(){

        this.register.click();
        this.regdog.click();
        this.other.click();
        this.fundstock.click();
        this.buttoncont.click();
        newWindow3();

    }

    public void VerifyRegisterDog8(){

        this.register.click();
        this.regdog.click();
        this.other.click();
        this.openreg.click();
        this.buttoncont.click();
        newWindow4();

    }

    public void VerifyRegisterDog9(){

        this.register.click();
        this.regdog.click();
        this.other.click();
        this.kenname.click();
        this.buttoncont.click();
        newWindow4();

    }

    public void VerifyRegisterDog5(){

        this.register.click();
        this.regdog.click();
        this.enrollpure.isDisplayed();
        this.enrollpure.click();
        this.buttoncont.click();
        newWindow3();

    }

    public void VerifyRegisterLitter(){

        this.register.click();
        this.reglitt.isDisplayed();
        this.reglitt.click();
        this.regalit.isDisplayed();
        this.regalittext.isDisplayed();
        this.mylitt.isDisplayed();
        this.mylitttext.isDisplayed();
        this.breezreg.isDisplayed();
        this.regalit.click();
        this.damsire.isDisplayed();
        this.damsiretext.isDisplayed();
        this.onlydam.isDisplayed();
        this.onlydamtext.isDisplayed();
        this.onlysire.isDisplayed();
        this.onlysiretext.isDisplayed();
        this.mylitt.click();
        this.fresh.isDisplayed();
        this.freshtext.isDisplayed();
        this.freshext.isDisplayed();
        this.freshexttext.isDisplayed();
        this.froze.isDisplayed();
        this.frozetext.isDisplayed();
        this.special.isDisplayed();
        this.specialtext.isDisplayed();
        this.breezreg.click();
        this.ezregopt.isDisplayed();
        this.ezregopttext.isDisplayed();
        this.puppyman.isDisplayed();
        this.puppymantext.isDisplayed();
        this.regalit.click();
        this.damsire.click();
        this.buttoncont.click();
        newWindow();

    }

    public void VerifyRegisterLitter2(){

        this.register.click();
        this.reglitt.click();
        this.regalit.click();
        this.onlydam.click();
        this.buttoncont.click();
        newWindow();

    }

    public void VerifyRegisterLitter3(){

        this.register.click();
        this.reglitt.click();
        this.regalit.isDisplayed();
        this.regalit.click();
        this.onlysire.click();
        this.buttoncont.click();
        newWindow();

    }

    public void VerifyRegisterLitter4(){

        this.register.click();
        this.reglitt.click();
        this.mylitt.click();
        this.fresh.click();
        this.buttoncont.click();
        newWindow4();

    }

    public void VerifyRegisterLitter5(){

        this.register.click();
        this.reglitt.click();
        this.mylitt.click();
        this.freshext.click();
        this.buttoncont.click();
        newWindow4();

    }

    public void VerifyRegisterLitter6(){

        this.register.click();
        this.reglitt.click();
        this.mylitt.click();
        this.froze.click();
        this.buttoncont.click();
        newWindow4();

    }

    public void VerifyRegisterLitter7(){

        this.register.click();
        this.reglitt.click();
        this.mylitt.click();
        this.special.click();
        this.buttoncont.click();
        newWindow4();

    }

    public void VerifyRegisterLitter8(){

        this.register.click();
        this.reglitt.click();
        this.breezreg.click();
        this.ezregopt.click();
        this.buttoncont.click();
        newWindow();

    }

    public void VerifyRegisterLitter9(){

        this.register.click();
        this.reglitt.click();
        this.breezreg.click();
        this.puppyman.click();
        this.buttoncont.click();
        newWindow();

    }

    public void VerifyTransOwner(){

        this.register.click();
        this.transown.click();
        this.transownheader.isDisplayed();
        this.transownbody.isDisplayed();
        this.transownbut.click();
        //this.transownform.isDisplayed();
        newWindow();

    }

    public void VerifyPurchPedig(){

        this.register.click();
        this.purcped.click();
        this.purcpedheader.isDisplayed();
        this.certped.isDisplayed();
        this.certpedbut.click();
        newWindow();

    }

    public void VerifyPurchPedig2(){

        this.register.click();
        this.purcped.click();
        this.purcpedheader.isDisplayed();
        this.onlinesear.isDisplayed();
        this.onlinesearbut.click();
        newWindow();

    }

    public void VerifyMoreInformation(){

        this.register.click();
        this.moreinfo.click();
        this.dogregmenu.isDisplayed();
        //this.dogregmenuexp.click();
        //this.dogregmenubody.isDisplayed();
        this.littregmenu.isDisplayed();
        //this.littregmenuexp.click();
        //this.littregmenubody.isDisplayed();
        this.feesched.isDisplayed();
        //this.feeschedexp.click();
        //this.feeschedbody.isDisplayed();
        this.rulregmenu.isDisplayed();
        //this.rulregmenuexp.click();
        //this.rulregmenubody.isDisplayed();
        this.dowforms.isDisplayed();
        //this.dowformsexp.click();
        //this.dowformsbody.isDisplayed();


    }




}
