package Pages;


import Helpers.DriverHelper;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static java.lang.Thread.sleep;


public class Homepage {

    @FindBy(xpath = "/html/body/div[2]/div/div[1]/a/img")
    WebElement akcicon;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[1]")
    WebElement headerhome;

    @FindBy(xpath = "//html/body/div[4]/div[2]/div/div[1]")
    WebElement picthome;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[1]/h2")
    WebElement topstories;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[2]/div[1]/div/div[1]/div/img")
    WebElement topstory1;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[2]/div[2]/div/div[1]/div/img")
    WebElement topstory2;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[2]/div[3]/div/div[2]/a")
    WebElement topstory3;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[2]/div[4]/div/div[1]/div/img")
    WebElement topstory4;

    @FindBy(xpath = "//html/body/div[4]/div[2]/div/div[1]/div[8]/div/a[2]")
    WebElement akctvheader;

    @FindBy(xpath = "//html/body/div[4]/div[7]/div[2]/div")
    WebElement videoheader;

    @FindBy(xpath = "//html/body/div[4]/div[6]/div[2]/div/div[2]/ul/li[1]/a/span[2]")
    WebElement videotitle1;

    @FindBy(xpath = "//html/body/div[4]/div[6]/div[2]/div/div[2]/ul/li[2]/a/span[2]")
    WebElement videotitle2;

    @FindBy(xpath = "//html/body/div[4]/div[6]/div[2]/div/div[2]/ul/li[3]/a/span[2]")
    WebElement videotitle3;

    @FindBy(xpath = "//html/body/div[4]/div[6]/div[2]/div/div[2]/ul/li[4]/a/span[2]")
    WebElement videotitle4;

    //@FindBy(xpath = "//html/body/div[4]/div[6]/div[3]/div/div/div[1]/div[1]/div/div/div/div[2]/video")
    //WebElement videoJW;

    @FindBy(xpath = "//html/body/div[4]/section[1]/div/div")
    WebElement articheader;

    @FindBy(css = "body > div.page-home.bgc-white.cmw > div.breed-feature > div:nth-child(1) > div > div.media-wrap > img")
    WebElement breedofday;

    @FindBy(xpath = "//html/body/div[4]/div[7]/div[2]/div/div/div/div[1]/div/h2")
    WebElement toolheader;

    @FindBy(xpath = "//html/body/div[4]/div[8]/div/div/div[1]/div[1]/h2")
    WebElement careheader;

    @FindBy(xpath = "//html/body/div[4]/div[8]/div/div/div[2]/img")
    WebElement careimg;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]")
    WebElement seheader;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[3]/a")
    WebElement eventbutton;

    @FindBy(xpath = "//html/body/div[4]/section[3]/div/div/div[2]/div/h2")
    WebElement regheader;

    @FindBy(xpath = "//html/body/div[4]/section[3]/div/div/div[1]/div/img")
    WebElement regimg;

    @FindBy(xpath = "//html/body/div[6]/div/div[1]/div[1]")
    WebElement akcf1;

    @FindBy(xpath = "//html/body/div[6]/div/div[2]/div[2]/div/div")
    WebElement social;

    @FindBy(xpath = "//html/body/div[6]/div/div[2]")
    WebElement footer;

    @FindBy(xpath = "//html/body/div[6]/div/div[3]/div[2]/div/ul/li[1]")
    WebElement akcf2;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[1]/nav[1]/a[1]")
    WebElement eventsearch;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[1]/nav[1]/a[2]")
    WebElement findpuppy;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[1]/nav[1]/a[3]")
    WebElement regdog;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[1]/nav[1]/a[4]")
    WebElement shop;

    @FindBy(xpath = "//*[@id='desktop-search']")
    WebElement search;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[1]")
    WebElement breeds;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[2]")
    WebElement expadv;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[3]")
    WebElement prodserv;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[4]")
    WebElement sports;

    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[5]")
    WebElement clubs;

    @FindBy(xpath = "//html/body/div[4]/div[2]/div/div[1]/div[3]/div/a[2]")
    WebElement trainicon;

    @FindBy(xpath = "//html/body/div[4]/div[2]/div/div[1]/div[2]/div/a[2]")
    WebElement registericon;

    @FindBy(xpath = "//*[@id='home__good-works-text-link']")
    WebElement careicon;

    @FindBy(xpath = "//html/body/div[4]/div[2]/div/div[1]/div[6]/div/a[2]")
    WebElement shopicon;

    @FindBy(xpath = "//html/body/div[4]/div[2]/div/div[1]/div[8]/div/a[2]")
    WebElement akctvicon;

    @FindBy(xpath = "//html/body/div[4]/div[2]/div/div[1]/div[7]/div/a[2]")
    WebElement sportsicon;

    @FindBy(xpath = "//*[@id=\"welcome\"]/div/a[1]/img")
    WebElement aboutakcicon;

    @FindBy(xpath = "//html/body/div[4]/div[2]/div/div[1]/div[4]/div/a[2]")
    WebElement findpuppyicon;

    @FindBy(xpath = "//html/body/div[4]/div[8]/div/div/div[1]/div[1]/h2")
    WebElement akccareval;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[2]/div/div/h1")
    WebElement aboutval;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[2]/div/div/h1")
    WebElement trainval;

    @FindBy(xpath = "//html/body/div[4]/div/div[4]/div/main/div[1]/div/div/h1")
    WebElement regisval;

    @FindBy(xpath = "//html/body/div[5]/main/div[2]/div[1]/h1")
    WebElement sportsval;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[2]/div[1]/div/div[2]/a")
    WebElement topsto1;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[2]/div[2]/div/div[2]/a")
    WebElement topsto2;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[2]/div[4]/div/div[2]/a")
    WebElement topsto4;

    @FindBy(xpath = "//html/body/div[4]/div[3]/div/div[2]/div[3]/div/div[2]/a")
    WebElement topsto3;

    @FindBy(xpath = "//*[@id=\"right-content-2\"]/a[1]/img")
    WebElement akctvimg;

    //@FindBy(xpath = "//html/body/div[1]/div/div/div/div/div[2]/div[2]/a[2]/img")
    //WebElement akctvimg2;

    @FindBy(xpath = "//*[@id='right-content-2']/a[2]/img")
    WebElement akctvimg2;

    @FindBy(xpath = "//html/body/div[1]/div/div/div/div/div[2]/div[2]/a[3]/img")
    WebElement akctvimg3;

    @FindBy(xpath = "//html/body/div[1]/div/div/div/div/div[2]/div[2]/a[4]/img")
    WebElement akctvimg4;

    @FindBy(xpath = "/html/body/div[4]/div[6]/div[3]/div/div/div[2]/div[1]")
    WebElement videoPreview;

    @FindBy(xpath = "//html/body/div[4]/div[6]/div[2]/div/div[2]/ul/li[2]/a/span[2]")
    WebElement videosel;

    @FindBy(xpath = "//html/body/div[5]/div/div/div/div/div/div/div/div[2]/video")
    WebElement video;

    @FindBy(xpath = "//*[@id=\"jwplayer_DjhUKBrg_F8rrYT0c_div\"]/div[8]/div[4]/div[1]/div[1]")
    WebElement videopause;

    @FindBy(xpath = "//html/body/div[4]/section[1]/div/div/div[2]/div[1]/div/div[2]/a")
    WebElement trendnews1;

    @FindBy(xpath = "//html/body/div[4]/section[1]/div/div/div[2]/div[2]/div/div[2]/a")
    WebElement trendnews2;

    @FindBy(xpath = "//html/body/div[4]/section[1]/div/div/div[2]/div[3]/div/div[2]/a")
    WebElement trendnews3;

    @FindBy(xpath = "//html/body/div[4]/div[7]/div[1]/div/div[2]/a")
    WebElement bofday;

    @FindBy(xpath = "//html/body/div[4]/div[7]/div[2]/div/div/div/div[2]/div[1]/a")
    WebElement expbreed;

    @FindBy(xpath = "//*[@id=\"panel-AKC Canine Health Foundation\"]/div/a")
    WebElement carebut1;

    @FindBy(xpath = "//*[@id=\"anchor-Rescue Network\"]/div/div")
    WebElement rescnet;

    @FindBy(xpath = "//*[@id=\"panel-Rescue Network\"]/div/a")
    WebElement rescnetbut;

    @FindBy(xpath = "//*[@id=\"anchor-AKC Reunite\"]/div/div")
    WebElement akcreun;

    @FindBy(xpath = "//*[@id=\"panel-AKC Reunite\"]/div/a")
    WebElement akcreunbut;

    @FindBy(xpath = "//*[@id=\"anchor-Humane Fund\"]/div/div")
    WebElement humanfund;

    @FindBy(xpath = "//*[@id=\"panel-Humane Fund\"]/div/a")
    WebElement humanfundbut;

    @FindBy(xpath = "//*[@id=\"anchor-Museum of the Dog\"]/div/div")
    WebElement museumdog;

    @FindBy(xpath = "//*[@id=\"panel-Museum of the Dog\"]/div/a")
    WebElement museumdogbut;

    @FindBy(xpath = "//*[@id=\"anchor-Protecting Your Rights\"]/div/div")
    WebElement protectrigh;

    @FindBy(xpath = "//*[@id=\"panel-Protecting Your Rights\"]/div/a")
    WebElement protectrightbut;

     @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[2]/div/div/span[2]")
    WebElement sportsarrow;

    //@FindBy(xpath = "//*[@id='icon-arrow-right']/path")
    //WebElement sportsarrow;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[5]/a/div[1]/h3")
    WebElement conf;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[6]/a/div[1]/h3")
    WebElement obe;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[7]/a/div[1]/h3")
    WebElement ral;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[8]/a/div[1]/h3")
    WebElement agi;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[9]/a/div[1]/h3")
    WebElement track;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[10]/a/div[1]/h3")
    WebElement herd;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[11]/a/div[1]/h3")
    WebElement earthdog;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[12]/a/div[1]/h3")
    WebElement fieldtri;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[13]/a/div[1]/h3")
    WebElement hunt;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[14]/a/div[1]/h3")
    WebElement farmdog;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[15]/a/div[1]/h3")
    WebElement lurecours;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[16]/a/div[1]/h3")
    WebElement coursabi;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[17]/a/div[1]/h3")
    WebElement fastcat;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[18]/a/div[1]/h3")
    WebElement conhound;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[19]/a/div[1]/h3")
    WebElement scentwork;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[2]/div[1]/div/div/div[20]/a/div[1]/h3")
    WebElement trickdog;

    @FindBy(xpath = "//html/body/div[4]/section[2]/div/div[3]/a")
    WebElement findevenearbut;

    @FindBy(xpath = "//html/body/div[4]/section[3]/div/div/div[2]/div/div[2]/div/a")
    WebElement regdogbut;

    @FindBy(xpath = "//html/body/div[4]/div[5]")
    WebElement add;

    @FindBy(xpath = "//html/body/div[4]/section[1]/div/div/div[2]/div[4]/div")
    WebElement add1;

    @FindBy(xpath = "//html/body/div[14]/div/a")
    WebElement closeadd;

    //@FindBy(xpath = "//html/body/div[15]")
    //WebElement closeadd;





    DriverHelper driverHelper;

    WebDriver driver;


    public Homepage(WebDriver _driver){
        this.driver = _driver;
        PageFactory.initElements(driver,this);
    }

    private void valid1() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://marketplace.akc.org/"));

    }

    private void valid2() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://shop.akc.org/"));

    }

    private void valid3() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://akc.tv/"));

    }

    private void validtopstory() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/conformation/national-championship/"));

    }

    private void validroku() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://channelstore.roku.com/"));

    }

    private void validapple() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://apps.apple.com/us/app/akc-tv"));

    }

    private void validamazon() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.amazon.com/gp/"));

    }

    private void validmagazine() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/products-services/magazines/"));

    }

    private void validbreedofday() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/dog-breeds/"));

    }

    private void validakccanine() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("http://www.akcchf.org/"));

    }

    private void validarescuenet() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/akc-rescue-network/"));

    }

    private void validakcreunite() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("http://www.akcreunite.org/"));

    }

    private void validhumanefund() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akchumanefund.org/"));

    }

    private void validmuseumofdog() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/museum-of-the-dog/"));

    }

    private void validprotectrights() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/clubs-delegates/government-relations/"));

    }

    private void validconformation() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/conformation/"));

    }

    private void validobedience() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/obedience/"));

    }

    private void validrally() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/rally/"));

    }

    private void validagility() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/agility/"));

    }

    private void validtracking() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/tracking/"));

    }

    private void validherding() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/herding/"));

    }

    private void validearthdog() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/earthdog/"));

    }

    private void validfieldtrials() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/pointing-breeds/"));

    }

    private void validfastcat() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/coursing/fast-cat/"));

    }

    private void validcoonhound() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/field-events-hounds/coonhound/"));

    }

    private void validscentwork() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/akc-scent-work/"));

    }

    private void validtrickdog() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/trick-dog/about-trick-dog/"));

    }

    private void validhunting() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/field-events-hounds/basset-hound-field-trials/"));

    }

    private void validfarmdog() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/herding/farm-dog-certified-test/"));

    }

    private void validlurecoursing() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/coursing/lure-coursing/"));

    }

    private void validcoursingability() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/sports/coursing/coursing-ability-test/"));

    }

    private void validfindevents() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.apps.akc.org/apps/event_calendar/"));

    }

    private void validregisterdog() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://www.akc.org/register/"));

    }

    private void validadd1() {
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://shop.akc.org/?utm_source=akc.org&utm_medium=house_display"));

    }




    public void CheckHomepage(){

        this.akcicon.isDisplayed();
        this.headerhome.isDisplayed();
        this.picthome.isDisplayed();
        this.topstories.isDisplayed();
        this.topstory1.isDisplayed();
        this.topstory2.isDisplayed();
        this.topstory3.isDisplayed();
        this.topstory4.isDisplayed();
        this.akctvheader.isDisplayed();
        this.videoheader.isDisplayed();
        this.videotitle1.isDisplayed();
        this.videotitle2.isDisplayed();
        this.videotitle3.isDisplayed();
        this.videotitle4.isDisplayed();
        //this.videoJW.isDisplayed();
        this.articheader.isDisplayed();
        this.breedofday.isDisplayed();
        this.toolheader.isDisplayed();
        this.careheader.isDisplayed();
        this.careimg.isDisplayed();
        this.seheader.isDisplayed();
        this.eventbutton.isDisplayed();
        this.regheader.isDisplayed();
        this.regimg.isDisplayed();
        this.akcf1.isDisplayed();
        this.social.isDisplayed();
        this.footer.isDisplayed();
        this.akcf2.isDisplayed();

    }

    public void Verifytopmenu(){
        this.eventsearch.isDisplayed();
        this.findpuppy.isDisplayed();
        this.regdog.isDisplayed();
        this.shop.isDisplayed();
        this.search.isDisplayed();
        this.breeds.isDisplayed();
        this.expadv.isDisplayed();
        this.prodserv.isDisplayed();
        this.sports.isDisplayed();
        this.clubs.isDisplayed();
    }

    public void VerifyAKCAbouticon(){

        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"welcome\"]/div/a[1]/img")));
        this.aboutakcicon.isDisplayed();
        this.aboutakcicon.click();
        this.aboutval.isDisplayed();
    }

    public void VerifyTrainingicon(){

        this.trainicon.click();
        this.trainval.isDisplayed();
    }

    public void VerifyRegistericon(){

        this.registericon.click();
        this.regisval.isDisplayed();
    }

    public void VerifySportsicon(){

        this.sportsicon.click();
        this.sportsval.isDisplayed();
    }

    public void VerifyAKCCareicon(){

        this.careicon.click();
        this.akccareval.isDisplayed();
    }

    public void VerifyFindPuppiesicon(){

        this.findpuppyicon.click();
        valid1();
    }

    public void VerifyShopicon(){

        this.shopicon.click();
        valid2();
    }

    public void VerifyAKCTVicon(){

        this.akctvicon.click();
        valid3();
    }

    public void VerifyTopstory1(){

        this.topsto1.click();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        final Boolean until = wait.until(ExpectedConditions.urlToBe("https://www.akc.org/expert-advice/lifestyle/best-dog-sweaters/"));
        //validtopstory();
    }

    public void VerifyTopstory2(){

        this.topsto2.click();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        final Boolean until = wait.until(ExpectedConditions.urlToBe("https://www.akc.org/expert-advice/dog-breeds/getting-right-belgian-malinois-good-fit/"));
        //validtopstory();
    }

    public void VerifyTopstory3(){

        this.topsto3.click();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        final Boolean until = wait.until(ExpectedConditions.urlToBe("https://www.akc.org/expert-advice/training/why-does-my-dog-jump-on-furniture/"));
        //validtopstory();
    }

    public void VerifyTopstory4(){

        this.topsto4.click();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        final Boolean until = wait.until(ExpectedConditions.urlToBe("https://www.akc.org/sports/conformation/national-championship/"));
        //validtopstory();
    }

    public void VerifyAKCTVimg1() throws InterruptedException {

        driver.manage().window().maximize();
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, 1100)");
        sleep(10000);
        this.akctvimg.click();
        valid3();
    }

    public void VerifyAKCTVimg2(){

        this.akctvimg2.click();
        validroku();
    }

    public void VerifyAKCTVimg3(){

        this.akctvimg3.click();
        validapple();
    }

    public void VerifyAKCTVimg4(){

        this.akctvimg4.click();
        validamazon();
    }

    public void VerifyVideo(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0, 1500);");
        this.videoPreview.isDisplayed();  // To validate JW player issues on preview section*
        this.videosel.isDisplayed();
        this.videosel.click();
        //this.video.click();  // To open the video on a new window IF needed
        this.videopause.click();
    }

    public void VerifyTrend1(){

        this.trendnews1.click();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlToBe("https://www.akc.org/expert-advice/training/learning-the-leave-it-command/"));
        //validtopstory();
    }

    public void VerifyTrend2(){

        this.trendnews2.click();
        validmagazine();
    }

    public void VerifyTrend3(){

        this.trendnews3.click();
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlToBe("https://www.akc.org/expert-advice/training/dog-sport-psychology-an-alternative-approach/"));
        //validtopstory();
    }

    public void VerifyBreedofDay(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0, 2000);");
        this.bofday.isDisplayed();
        this.bofday.click();
        validbreedofday();
    }

    public void VerifyExpBreeds(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,2000);");
        this.expbreed.click();
        validbreedofday();
    }

    public void VerifyAKCCanine(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,2300);");
        this.carebut1.click();
        validakccanine();
    }

    public void VerifyRescueNet(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,2400);");
        this.rescnet.isDisplayed();
        this.rescnet.click();
        this.rescnetbut.click();
        validarescuenet();
    }

    public void VerifyAKCReunite(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,2500);");
        this.akcreun.isDisplayed();
        this.akcreun.click();
        this.akcreunbut.click();
        validakcreunite();
    }

    public void VerifyHumaneFund(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,2500);");
        this.humanfund.click();
        this.humanfundbut.click();
        validhumanefund();
    }

    public void VerifyMuseumofDog(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,2500);");
        this.museumdog.click();
        this.museumdogbut.click();
        validmuseumofdog();
    }

    public void VerifyProtectRights(){

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0,2600);");
        this.protectrigh.isDisplayed();
        this.protectrigh.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"panel-Protecting Your Rights\"]/div/a")));
        this.protectrightbut.isDisplayed();
        this.protectrightbut.click();
        validprotectrights();
    }

    public void VerifyConformation(){

        this.conf.click();
        validconformation();
    }

    public void VerifyObedience(){

        this.obe.click();
        validobedience();
    }

    public void VerifyRally(){

        this.ral.click();
        validrally();
    }

    public void VerifyAgility(){

        this.agi.click();
        validagility();
    }

    public void VerifyTracking(){
        this.sportsarrow.click();
        this.track.click();
        validtracking();
    }

    public void VerifyHerding()  throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.herd.click();
        validherding();
    }

    public void VerifyEarthDog() throws InterruptedException {
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.earthdog.click();
        validearthdog();
    }

    public void VerifyFieldTrials() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.fieldtri.click();
        validfieldtrials();
    }

    public void VerifyHunting() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.hunt.click();
        validhunting();
    }

    public void VerifyFarmDog() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.farmdog.click();
        validfarmdog();
    }

    public void VerifyLureCoursing() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.lurecours.click();
        validlurecoursing();
    }

    public void VerifyCoursingAbility() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.coursabi.click();
        validcoursingability();
    }

    public void VerifyFastCat() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.fastcat.click();
        validfastcat();
    }

    public void VerifyCoounhound() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.conhound.click();
        validcoonhound();
    }

    public void VerifyScentWork() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.scentwork.click();
        validscentwork();
    }

    public void VerifyTrickDog() throws InterruptedException{
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.sportsarrow.click();
        sleep(1000);
        this.trickdog.click();
        validtrickdog();
    }

    public void VerifyFindEvents(){

        this.findevenearbut.click();
        validfindevents();
    }

    public void VerifyRegisterDogbut(){

        this.regdogbut.click();
        validregisterdog();
    }


    //Adds Verify & Click solutions

    public void VerifyAdd() throws InterruptedException {

        this.add.isDisplayed();

    }

    public void ClickAdd() throws InterruptedException {

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0, 1500);");
        Thread.sleep(3000);
        this.add.isDisplayed();
        this.add.click();
        ClickOpenAdd();

    }

    public void VerifyAdd1() throws InterruptedException {

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0, 2500);");
        Thread.sleep(3000);
        this.add1.isDisplayed();

    }

    public void ClickAdd1() throws InterruptedException {

        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("scroll(0, 2000);");
        Thread.sleep(3000);
        this.add1.isDisplayed();
        this.add1.click();
        ClickOpenAdd();

    }

    public void Navigate(){

        this.sportsarrow.click();

    }

    public void CloseAdd() {

        WebDriverWait wait = new WebDriverWait(driver, 30);
       // wait.until(blueadd.isDisplayed());
        Actions action = new Actions(driver);
        action.sendKeys(Keys.ESCAPE);

    }

    public void ClickOpenAdd() {

        for (String winHandle : driver.getWindowHandles()) driver.switchTo().window(winHandle);
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https:"));

    }

}













