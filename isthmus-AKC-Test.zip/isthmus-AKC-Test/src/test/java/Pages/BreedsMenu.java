package Pages;

import Helpers.DriverHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static java.lang.Thread.sleep;

public class BreedsMenu {


    @FindBy(xpath = "//html/body/div[2]/div/div[1]/div/div[2]/nav/a[1]")
    WebElement menubreeds;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[1]/div/div/a")
    WebElement viewbreeds;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[1]/div/div/form/div[1]/div/div[1]")
    WebElement searchbreeds;

    @FindBy(xpath = "//*[@id='breed_group-selectized']")
    WebElement explorebreeds;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[2]/div/div/div/ul/li[1]/a/div")
    WebElement findmatch;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[2]/div/div/div/ul/li[2]/a/div")
    WebElement comparebreeds;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[2]/div/div/div/ul/li[3]/a/div")
    WebElement findapuppy;

    @FindBy(xpath = "//*[@id=\"dog-breeds\"]/div[3]/div/div/div/ul/li[1]/a")
    WebElement chooseabreed;

    @FindBy(css = "#dog-breeds > div:nth-child(3) > div > div > div > ul > li:nth-child(2) > a")
    WebElement whygetdog;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[3]/div/div/div/ul/li[3]/a")
    WebElement findrespbreeder;

    @FindBy(xpath = "//*[@id=\"dog-breeds\"]/div[3]/div/div/div/ul/li[4]/a")
    WebElement getstartdogsports;

    @FindBy(css = "#dog-breeds > div:nth-child(3) > div > div > div > ul > li:nth-child(5) > a")
    WebElement allaboutpuppies;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[4]/div/div/div/ul/li[1]/a")
    WebElement findpurebreed;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[4]/div/div/div/ul/li[2]/a")
    WebElement menuregdog;

    @FindBy(xpath = "//html/body/div[2]/div/div[2]/div[1]/div[4]/div/div/div/ul/li[3]/a")
    WebElement findbreedclub;

    @FindBy(xpath = "//*[@id=\"dog-breeds\"]/div[4]/div/div/div/ul/li[4]/a")
    WebElement mostpopdogs;

    @FindBy(xpath = "//*[@id=\"dog-breeds\"]/div[4]/div/div/div/ul/li[5]/a")
    WebElement fordogbreeders;

    @FindBy(xpath = "//*[@id=\"dog-breeds\"]/div[4]/div/div/div/ul/li[6]/a")
    WebElement fordogowners;

    @FindBy(xpath = "//*[@id=\"page-title\"]/h1")
    WebElement chooseabreedElement;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/div[1]/h1")
    WebElement whygetdogElement;

    @FindBy(xpath = "//html/body/div[6]/div/div[2]/div[1]/h1")
    WebElement findrespbreederElement;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/div[1]/h1")
    WebElement getstartdogsportsElement;

    @FindBy(xpath = "//html/body/div[7]/div/div[2]/div[1]/h1")
    WebElement allaboutpuppiesElement;

    @FindBy(xpath = "//html/body/div[4]/div/div[3]/div/span")
    WebElement menuregdogElement;

    @FindBy(xpath = "//*[@id=\"page-title\"]/h1")
    WebElement mostpopdogsElement;

    @FindBy(xpath = "//*[@id=\"page-title\"]/div/h1")
    WebElement fordogbreedersElement;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/div[1]/h1")
    WebElement fordogownersElement;

    @FindBy(xpath = "//html/body/div[5]/div[1]/div[2]/div[1]/h1")
    WebElement viewbreedsElement;

    @FindBy(xpath = "//*[@id=\"mega-menu\"]")
    WebElement searchbreedsElement;

    @FindBy(xpath = "//*[@id=\"mega-menu\"]")
    WebElement explorebreedsElement;

    @FindBy(xpath = "//*[@id=\"breed-select-template\"]/div/div/div[2]/main/div[2]/div[1]/h1")
    WebElement findmatchElement;

    @FindBy(xpath = "//html/body/div[5]/div/div/div[2]/main/div[2]/div[1]/h1")
    WebElement comparebreedsElement;

    @FindBy(xpath = "//*[@id=\"main-content\"]/div[1]/div[2]/div/div/ul[2]/li[1]/a")
    WebElement preparingPuppy;

    @FindBy(xpath = "/html/body/div[6]/div[1]/div[3]/aside/div/nav/ul/li[2]/a")
    WebElement twoMonths;

    @FindBy(xpath = "/html/body/div[6]/div[1]/div[3]/aside/div/nav/ul/li[3]/a")
    WebElement threeMonths;

    @FindBy(css = "body > div:nth-child(7) > div.page-container > div.page-layout > main > div.content-card-grid > div > div > div:nth-child(1) > div > div.content-card__body > a")
    WebElement newPuppyCheck;

    @FindBy(css = "#main-content > div.article-body > ul > li:nth-child(2) > a")
    WebElement newPuppyCheckElement;

    @FindBy(css = "body > div:nth-child(6) > div.page-container > div.page-layout > main > div.content-card-grid > div > div > div:nth-child(12) > div > div.content-card__body > a")
    WebElement threeMonthsElement;

    @FindBy(xpath = "//*[@id=\"main-content\"]/div[1]/div[2]/div/div/div/ul/li[1]/span/span")
    WebElement accordion18;

    @FindBy(xpath = "//*[@id=\"main-content\"]/div[1]/div[2]/div/div/div/ul/li[1]/div/ol/li[4]/a/span")
    WebElement frenchBull;

    @FindBy(xpath = "//*[@id=\"main-content\"]/div[1]/div[2]/div/div/div/ul/li[1]/div/p[2]/a/span")
    WebElement fullList;

    @FindBy(xpath = "//html/body/div[5]/div/div[2]/main/div[3]/div/div/div/table/tbody/tr[2]/td[1]/a/span")
    WebElement retriever;

    @FindBy(xpath = "//*[@id=\"main-content\"]/div[1]/div[2]/div/div/div/ul/li[3]/span/span")
    WebElement accordion16;

    @FindBy(xpath = "//*[@id=\"main-content\"]/div[1]/div[2]/div/div/div/ul/li[3]/div/ol/li[2]/a")
    WebElement germanShepherd;

    @FindBy(css = "#page-title > h1")
    WebElement germanShepherdElement;

    @FindBy(xpath = "/html/body/div[5]/div/div[2]/aside/div/nav/ul/li[2]/a")
    WebElement AKCBreederOfMeritProgramMenu;

    @FindBy(xpath = "//*[@id=\"page-title\"]/div/h1")
    WebElement SearchBreMeritElement;

    @FindBy(css = "#main-content > div.article-body > div.content-body > div > div > table > tbody > tr:nth-child(1) > td:nth-child(2) > p:nth-child(4) > a")
    WebElement breedsMoreButton;

    @FindBy(xpath = "//*[@id=\"main-content\"]/div[1]/div[1]/div/div/table/tbody/tr[4]/td[2]/p[3]/a")
    WebElement dogHealthButton;


    DriverHelper driverHelper;

    WebDriver driver;

    // Constructor
    public BreedsMenu(WebDriver _driver) {
        this.driver = _driver;
        PageFactory.initElements(driver, this);
    }

    public void Verifybreedsmenu() {

        this.menubreeds.click();
        this.viewbreeds.isDisplayed();
        this.searchbreeds.isDisplayed();
        this.explorebreeds.isDisplayed();
        this.findmatch.isDisplayed();
        this.comparebreeds.isDisplayed();
        this.findapuppy.isDisplayed();
        this.chooseabreed.isDisplayed();
        this.whygetdog.isDisplayed();
        this.findrespbreeder.isDisplayed();
        this.getstartdogsports.isDisplayed();
        this.allaboutpuppies.isDisplayed();
        this.findpurebreed.isDisplayed();
        this.menuregdog.isDisplayed();
        this.findbreedclub.isDisplayed();
        this.mostpopdogs.isDisplayed();
        this.fordogbreeders.isDisplayed();
        this.fordogowners.isDisplayed();

    }


    //Click methods for Breeds.Menu tabs


    public void Clickviewbreeds() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.viewbreeds.isDisplayed();
        this.viewbreeds.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.viewbreedsElement.isDisplayed();

    }

    public void Clicksearchbreeds() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.searchbreeds.isDisplayed();
        this.searchbreeds.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.searchbreedsElement.isDisplayed();

    }

    public void Clickexplorebreeds() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.explorebreeds.isDisplayed();
        this.explorebreeds.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.explorebreedsElement.isDisplayed();

    }

    public void Clickfindmatch() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.findmatch.isDisplayed();
        this.findmatch.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.findmatchElement.isDisplayed();

    }

    public void Clickcomparebreeds() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.comparebreeds.isDisplayed();
        this.comparebreeds.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.comparebreedsElement.isDisplayed();

    }

    public void Clickfindapuppy() throws InterruptedException {  // New tab method :

        this.menubreeds.click();
        sleep(1000);
        this.findapuppy.isDisplayed();
        this.findapuppy.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://marketplace.akc.org/"));

    }

    public void Clickchooseabreed() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.chooseabreed.isDisplayed();
        this.chooseabreed.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.chooseabreedElement.isDisplayed();

    }

    public void Clickwhygetdog() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#dog-breeds > div:nth-child(3) > div > div > div > ul > li:nth-child(2) > a")));
        this.whygetdog.isDisplayed();
        this.whygetdog.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.whygetdogElement.isDisplayed();

    }

    public void Clickfindrespbreeder() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.findrespbreeder.isDisplayed();
        this.findrespbreeder.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.findrespbreederElement.isDisplayed();

    }

    public void Clickgetstartdogsports() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.getstartdogsports.isDisplayed();
        this.getstartdogsports.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.getstartdogsportsElement.isDisplayed();

    }

    public void Clickallaboutpuppies() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.allaboutpuppies.isDisplayed();
        this.allaboutpuppies.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.allaboutpuppiesElement.isDisplayed();

    }

    public void Clickfindpurebreed() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.findpurebreed.isDisplayed();
        this.findpurebreed.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://marketplace.akc.org/puppies"));

    }

    public void Clickmenuregdog() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.menuregdog.isDisplayed();
        this.menuregdog.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.menuregdogElement.isDisplayed();

    }

    public void Clickfindbreedclub() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.findbreedclub.isDisplayed();
        this.findbreedclub.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        for (String winHandle : driver.getWindowHandles()) {
            driver.switchTo().window(winHandle);
        }
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.urlContains("https://webapps.akc.org/club-search/"));

    }

    public void Clickmostpopdogs() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"dog-breeds\"]/div[4]/div/div/div/ul/li[4]/a")));
        this.mostpopdogs.isDisplayed();
        this.mostpopdogs.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.mostpopdogsElement.isDisplayed();

    }

    public void Clickfordogbreeders() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"dog-breeds\"]/div[4]/div/div/div/ul/li[5]/a")));
        this.fordogbreeders.isDisplayed();
        this.fordogbreeders.click();
        //this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.fordogbreedersElement.isDisplayed();

    }

    public void Clickfordogowners() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"dog-breeds\"]/div[4]/div/div/div/ul/li[6]/a")));
        this.fordogowners.isDisplayed();
        this.fordogowners.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.fordogownersElement.isDisplayed();

    }

    //Articles methods >


    public void puppiesArticle1() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.allaboutpuppies.isDisplayed();
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(870, 20)");
        this.allaboutpuppies.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.preparingPuppy.isDisplayed();
        this.preparingPuppy.click();
        this.twoMonths.isDisplayed(); //Fix this >
        this.twoMonths.click();
        this.threeMonths.isDisplayed();
        //this.threeMonths.click();
        //this.ThreeMonthsElement.isDisplayed();

    }

    public void puppiesArticle2() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.allaboutpuppies.isDisplayed();
        this.allaboutpuppies.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, 1600)");
        this.preparingPuppy.isDisplayed();
        this.preparingPuppy.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.newPuppyCheck.isDisplayed();
        jse.executeScript("scroll(716, 659)");
        this.newPuppyCheck.click();
        this.newPuppyCheckElement.isDisplayed();

    }

    public void puppiesArticle3() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.allaboutpuppies.isDisplayed();
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(870, 20)");
        this.allaboutpuppies.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.preparingPuppy.isDisplayed();
        this.preparingPuppy.click();
        this.threeMonths.isDisplayed();
        this.threeMonths.click();
        this.threeMonthsElement.isDisplayed();

    }

    public void mostpopdogsArticle1() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.mostpopdogs.isDisplayed();
        this.mostpopdogs.click();
        sleep(1000);
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.mostpopdogsElement.isDisplayed();
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, 1000)");
        this.accordion18.isDisplayed();
        this.accordion18.click();
        sleep(1000);
        this.frenchBull.isDisplayed();
        this.fullList.isDisplayed();
        this.fullList.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        sleep(1000);
        this.retriever.isDisplayed();

    }

    public void mostpopdogsArticle2() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.mostpopdogs.isDisplayed();
        this.mostpopdogs.click();
        sleep(1000);
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.mostpopdogsElement.isDisplayed();
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, 1000)");
        this.accordion16.isDisplayed();
        this.accordion16.click();
        sleep(1000);
        this.germanShepherd.isDisplayed();
        this.germanShepherd.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.germanShepherdElement.isDisplayed();

    }

    public void fordogbreedersArticle1() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.fordogbreeders.isDisplayed();
        this.fordogbreeders.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        this.AKCBreederOfMeritProgramMenu.isDisplayed();
        this.AKCBreederOfMeritProgramMenu.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        sleep(1000);
        this.SearchBreMeritElement.isDisplayed();

    }

    public void ForDogOwnerArticle1() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.fordogowners.isDisplayed();
        this.fordogowners.click();
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        sleep(1000);
        this.breedsMoreButton.isDisplayed();
        this.breedsMoreButton.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.urlToBe("https://www.akc.org/dog-breed-selector/"));
        driver.navigate().to("https://www.akc.org/dog-owners/");

    }

    public void ForDogOwnerArticle2() throws InterruptedException {

        this.menubreeds.click();
        sleep(1000);
        this.fordogowners.isDisplayed();
        this.fordogowners.click();
        sleep(1000);
        this.driver.get(this.driver.getCurrentUrl() + "?test=true");
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("scroll(0, 1000)");
        this.dogHealthButton.isDisplayed();
        this.dogHealthButton.click();
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.urlToBe("https://www.akc.org/expert-advice/health/"));

    }


}

