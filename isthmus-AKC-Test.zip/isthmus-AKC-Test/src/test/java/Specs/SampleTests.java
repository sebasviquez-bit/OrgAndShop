package Specs;

import Helpers.DataHelper;
import Model.User;
import Model.Word;
import org.testng.annotations.Test;


public class SampleTests extends SpecsBaseClass {

    @Test (dataProvider = "RegisterUsers", dataProviderClass = DataHelper.class)
    public void SuccessfulRegister(String sUserName, String sFirstName, String sLastName, String sPassword1, String sPassword2) throws InterruptedException {

        driver.manage().window().maximize();
        User testUser;
        testUser = new User(sUserName, sFirstName, sLastName, sPassword1, sPassword2);
        register.registerUser(testUser);

    }

    @Test (dataProvider = "ExistingUsers", dataProviderClass = DataHelper.class)
    public void SuccessfulLogin(String sEmail, String sPassword) throws InterruptedException {

        driver.manage().window().maximize();
        User testUser = new User(sEmail, sPassword);
        signIn.signInUser(testUser);

    }

    @Test
    public void HomepageCheck() {

        driver.manage().window().maximize();
        homepage.CheckHomepage();

    }

    @Test
    public void TopMenu() {

        driver.manage().window().maximize();
        homepage.Verifytopmenu();

    }

    @Test
    public void BreedMenu() {

        driver.manage().window().maximize();
        breeds.Verifybreedsmenu();

    }

    @Test
    public void ExpAdviceVerify() {

        driver.manage().window().maximize();
        expertAdvice.VerifyExpAdv();

    }

    @Test
    public void ProdServVerify() {

        driver.manage().window().maximize();
        prodserv.VerifyProdServ();

    }

    @Test
    public void SportsEventsVerify() {

        driver.manage().window().maximize();
        sportsEvents.VerifySportsEvents();

    }

    @Test
    public void ClubsDelegatesVerify() {

        driver.manage().window().maximize();
        clubsDelegates.VerifyClubsDelegates();

    }

    @Test
    public void CompareBreedsVerify() {

        driver.manage().window().maximize();
        compareBreeds.VerifyCompareBreeds();

    }

    @Test
    public void BreedSelectorVerify1() {

        driver.manage().window().maximize();
        breedSelector.VerifyBreedSelector1();

    }

    @Test
    public void BreedSelectorVerify2() {

        driver.manage().window().maximize();
        breedSelector.VerifyBreedSelector2();

    }

    @Test
    public void BreedSelectorVerify3() {

        driver.manage().window().maximize();
        breedSelector.VerifyBreedSelector3();

    }

    @Test
    public void VerifyDogName() {

        driver.manage().window().maximize();
        dogName.DogNameVerify();

    }

    @Test
    public void CanMyDogEatVerify1() {

        canMyDogEat.VerifyCanMyDogEat1();

    }

    @Test
    public void CanMyDogEatVerify2() {

        canMyDogEat.VerifyCanMyDogEat2();
    }

    @Test
    public void RegisterDogVerify1() {

        homepage.CloseAdd();
        registerDog.VerifyRegisterDog1();

    }

    @Test
    public void RegisterDogVerify2() {

        registerDog.VerifyRegisterDog2();

    }

    @Test
    public void RegisterDogVerify3() {

        registerDog.VerifyRegisterDog3();

    }

    @Test
    public void RegisterDogVerify4() {

        driver.manage().window().maximize();
        registerDog.VerifyRegisterDog4();

    }

    @Test (dataProvider = "WordSearch", dataProviderClass = DataHelper.class)
    public void SearchVerify(String sWord) throws InterruptedException {

        Word searchWord;
        searchWord = new Word(sWord);
        search.SearchPage(searchWord);

    }

    @Test
    public void RegisterDogVerify5() {

        driver.manage().window().maximize();
        registerDog.VerifyRegisterDog5();

    }

    @Test
    public void RegisterDogVerify6() {

        registerDog.VerifyRegisterDog6();

    }

    @Test
    public void RegisterDogVerify7() {

        registerDog.VerifyRegisterDog7();

    }

    @Test
    public void RegisterDogVerify8() {

        registerDog.VerifyRegisterDog8();

    }

    @Test
    public void RegisterDogVerify9() {

        registerDog.VerifyRegisterDog9();

    }

    @Test
    public void RegisterLitterVerify() {

        registerDog.VerifyRegisterLitter();

    }

    @Test
    public void RegisterLitterVerify2() {

        registerDog.VerifyRegisterLitter2();

    }

    @Test
    public void RegisterLitterVerify3() {

        registerDog.VerifyRegisterLitter3();

    }

    @Test
    public void RegisterLitterVerify4() {

        registerDog.VerifyRegisterLitter4();

    }

    @Test
    public void RegisterLitterVerify5() {

        registerDog.VerifyRegisterLitter5();

    }

    @Test
    public void RegisterLitterVerify6() {

        registerDog.VerifyRegisterLitter6();

    }

    @Test
    public void RegisterLitterVerify7() {

        registerDog.VerifyRegisterLitter7();

    }

    @Test
    public void RegisterLitterVerify8() {

        registerDog.VerifyRegisterLitter8();

    }

    @Test
    public void RegisterLitterVerify9() {

        registerDog.VerifyRegisterLitter9();

    }

    @Test
    public void TransOwnerVerify() {

        registerDog.VerifyTransOwner();

    }

    @Test
    public void PurchPediVerify() {

        registerDog.VerifyPurchPedig();

    }

    @Test
    public void PurchPediVerify2() {

        registerDog.VerifyPurchPedig2();

    }

    @Test
    public void MoreInfoVerify() {

        registerDog.VerifyMoreInformation();

    }

    @Test
    public void AboutVerify() {

        homepage.VerifyAKCAbouticon();

    }

    @Test
    public void RegisterVerify() {

        homepage.VerifyRegistericon();

    }

    @Test
    public void TrainingVerify() {

        homepage.VerifyTrainingicon();

    }

    @Test
    public void SportsVerify() {

        homepage.VerifySportsicon();

    }

    @Test
    public void AKCCareVerify() {

        homepage.VerifyAKCCareicon();

    }

    @Test
    public void FindPuppiesVerify() {

        homepage.VerifyFindPuppiesicon();

    }

    @Test
    public void ShopVerify() {

        homepage.VerifyShopicon();

    }

    @Test
    public void AKCTVVerify() {

        homepage.VerifyAKCTVicon();

    }

    @Test
    public void TopStoryVerify1() {

        homepage.VerifyTopstory1();

    }

    @Test
    public void TopStoryVerify2() {

        homepage.VerifyTopstory2();

    }

    @Test
    public void TopStoryVerify3() {

        homepage.VerifyTopstory3();

    }

    @Test
    public void TopStoryVerify4() {

        homepage.VerifyTopstory4();

    }

    //@Test
    public void AKCTVimgVerify1() throws InterruptedException {

        homepage.VerifyAKCTVimg1();

    }

    //@Test
    public void AKCTVimgVerify2() {

        homepage.VerifyAKCTVimg2();

    }

    //@Test
    public void AKCTVimgVerify3() {

        homepage.VerifyAKCTVimg3();

    }

    //@Test
    public void AKCTVimgVerify4() {

        homepage.VerifyAKCTVimg4();

    }

    @Test
    public void VideoVerify() {

        driver.manage().window().maximize();
        homepage.VerifyVideo();

    }

    @Test
    public void TrendVerify1() {

        homepage.VerifyTrend1();

    }

    @Test
    public void TrendVerify2() {

        homepage.VerifyTrend2();

    }

    @Test
    public void TrendVerify3() {

        homepage.VerifyTrend3();

    }

    @Test
    public void BreedofDayVerify() {

        homepage.VerifyBreedofDay();

    }

    @Test
    public void ExpBreedsVerify() {

        homepage.VerifyExpBreeds();

    }

    @Test
    public void AKCCanineVerify() {

        homepage.VerifyAKCCanine();

    }

    @Test
    public void RescueNetVerify() {

        homepage.VerifyRescueNet();

    }

    @Test
    public void AKCReuniteVerify() {

        homepage.VerifyAKCReunite();

    }

    @Test
    public void HumaneFundVerify() {

        homepage.VerifyHumaneFund();

    }

    @Test
    public void MuseumofDogVerify() {

        homepage.VerifyMuseumofDog();

    }

    @Test
    public void ProtectRightsVerify() {

        homepage.VerifyProtectRights();

    }

    @Test
    public void ConformationVerify() {

        homepage.VerifyConformation();

    }

    @Test
    public void ObedienceVerify() {

        homepage.VerifyObedience();

    }

    @Test
    public void RallyVerify() {

        homepage.VerifyRally();

    }

    @Test
    public void AgilityVerify() {

        homepage.VerifyAgility();

    }

    @Test
    public void TrackingVerify() {

        homepage.VerifyTracking();

    }

    @Test
    public void HerdingVerify() throws InterruptedException {

        homepage.VerifyHerding();

    }

    @Test
    public void EarthDogVerify() throws InterruptedException {

        homepage.VerifyEarthDog();

    }

    @Test
    public void FieldTrialsVerify() throws InterruptedException {

        homepage.VerifyFieldTrials();

    }

    @Test
    public void HuntingVerify() throws InterruptedException {

        homepage.VerifyHunting();

    }

    @Test
    public void FarmDogVerify() throws InterruptedException {

        homepage.VerifyFarmDog();

    }

    @Test
    public void LureCoursingVerify() throws InterruptedException {

        homepage.VerifyLureCoursing();

    }

    @Test
    public void CoursingAbilityVerify() throws InterruptedException {

        homepage.VerifyCoursingAbility();

    }

    @Test
    public void FastCatVerify() throws InterruptedException {

        homepage.VerifyFastCat();

    }

    @Test
    public void CoonhoundVerify() throws InterruptedException {

        homepage.VerifyCoounhound();

    }

    @Test
    public void ScentWorkVerify() throws InterruptedException {

        homepage.VerifyScentWork();

    }

    @Test
    public void TrickDogVerify() throws InterruptedException {

        homepage.VerifyTrickDog();

    }

    @Test
    public void FindEventsbutVerify() {

        homepage.VerifyFindEvents();

    }

    @Test
    public void RegisterDogbutVerify() {

        homepage.VerifyRegisterDogbut();

    }

    //Test for Adds Verify & Click

    @Test
    public void AddVerify() throws InterruptedException {

        driver.manage().window().maximize();
        homepage.VerifyAdd();

    }

    @Test
    public void ClickAdd() throws InterruptedException {

        driver.manage().window().maximize();
        homepage.ClickAdd();

    }

    @Test
    public void VerifyAdd1() throws InterruptedException {

        driver.manage().window().maximize();
        homepage.VerifyAdd1();

    }

    @Test
    public void ClickAdd1() throws InterruptedException {

        driver.manage().window().maximize();
        homepage.ClickAdd1();

    }


    //Test for Breeds Menu click action >


    @Test
    public void Clickviewbreeds() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickviewbreeds();

    }

    @Test
    public void Clicksearchbreeds() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clicksearchbreeds();

    }

    @Test
    public void Clickexplorebreeds() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickexplorebreeds();

    }

    @Test
    public void Clickfindmatch() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickfindmatch();

    }

    @Test
    public void Clickcomparebreeds() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickcomparebreeds();

    }

    @Test
    public void Clickfindapuppy() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickfindapuppy();

    }

    @Test
    public void Clickchooseabreed() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickchooseabreed();

    }

    @Test
    public void Clickwhygetdog() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickwhygetdog();

    }

    @Test
    public void Clickfindrespbreeder() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickfindrespbreeder();

    }

    @Test
    public void Clickgetstartdogsports() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickgetstartdogsports();

    }

    @Test
    public void Clickallaboutpuppies() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickallaboutpuppies();

    }

    @Test
    public void Clickfindpurebreed() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickfindpurebreed();

    }

    @Test
    public void Clickmenuregdog() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickmenuregdog();

    }

    @Test
    public void Clickfindbreedclub() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickfindbreedclub();

    }

    @Test
    public void Clickmostpopdogs() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickmostpopdogs();

    }

    @Test
    public void Clickfordogbreeders() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickfordogbreeders();

    }

    @Test
    public void Clickfordogowners() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.Clickfordogowners();

    }


    //Tests for ExpertAdvice Menu Click action >

    @Test
    public void Clickartexpadv() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickartexpadv();

    }

    @Test
    public void Clickallcateg() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickallcateg();

    }

    @Test
    public void Clickdogbreeding() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickdogbreeding();

    }

    @Test
    public void Clickgrooming() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickgrooming();

    }

    @Test
    public void Clickhealth() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickhealth();

    }

    @Test
    public void Clickhomeliving() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickhomeliving();

    }

    @Test
    public void Clicklifestyle() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clicklifestyle();

    }

    @Test
    public void Clicknews() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clicknews();

    }

    @Test
    public void Clicknutrition() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clicknutrition();

    }

    @Test
    public void Clickpuppyinfo() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickpuppyinfo();

    }

    @Test
    public void Clicksports() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clicksports();

    }

    @Test
    public void Clicktraining() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clicktraining();

    }

    @Test
    public void Clickvetcorner() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickvetcorner();

    }

    @Test
    public void ClickfindmatchOnExpAdvMenu() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.ClickfindmatchOnExpAdvMenu();

    }

    @Test
    public void Clickdognamefind() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickdognamefind();

    }

    @Test
    public void Clickcandogeat() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickcandogeat();

    }

    @Test
    public void Clickakctv() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickakctv();

    }

    @Test
    public void Clickakcmag() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickakcmag();

    }

    @Test
    public void Clicknewsletter() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clicknewsletter();

    }

    @Test
    public void Clickpresscenter() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickpresscenter();

    }

    @Test
    public void Clickakcdetection() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickakcdetection();

    }

    @Test
    public void Clickakccanine() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickakccanine();

    }

    @Test
    public void Clickgovernment() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickgovernment();

    }

    @Test
    public void Clickakceducation() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickakceducation();

    }

    @Test
    public void Clickakclibrary() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.Clickakclibrary();

    }

     //Tests for ProdServ Menu Click action >


    @Test
    public void Clickshopdog() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickshopdog();

    }

    @Test
    public void Clickbreedspecif() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickbreedspecif();

    }

    @Test
    public void Clicktoystreats() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clicktoystreats();

    }

    @Test
    public void Clicktrainingprod() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clicktrainingprod();

    }

    @Test
    public void Clickdoggift() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickdoggift();

    }

    @Test
    public void Clickdna() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickdna();

    }

    @Test
    public void ClickakctvProdServ() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.ClickakctvProdServ();

    }

    @Test
    public void ClickakcmagProdServ() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.ClickakcmagProdServ();

    }

    @Test
    public void Clickpedigrees() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickpedigrees();

    }

    @Test
    public void Clickbreedrep() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickbreedrep();

    }

    @Test
    public void Clickakccomp() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakccomp();

    }

    @Test
    public void Clickregdog() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickregdog();

    }

    @Test
    public void Clickregpure() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickregpure();

    }

    @Test
    public void reglitter() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.reglitter();

    }

    @Test
    public void Clickenroll() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickenroll();

    }

    @Test
    public void Clickregdown() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickregdown();

    }

    @Test
    public void Clickfinddog() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickfinddog();

    }

    @Test
    public void Clickfinpuppy() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickfinpuppy();

    }

    @Test
    public void Clickakcrescue() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakcrescue();

    }

    @Test
    public void Clickbreedrefer() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickbreedrefer();

    }

    @Test
    public void Clickpuppyvisor() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickpuppyvisor();

    }

    @Test
    public void Clicktrainserv() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clicktrainserv();

    }

    @Test
    public void Clickcgc() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickcgc();

    }

    @Test
    public void Clickgooddog() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickgooddog();

    }

    @Test
    public void Clickfindtrainclub() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickfindtrainclub();

    }

    @Test
    public void Clickakccaninecolle() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakccaninecolle();

    }

    @Test
    public void Clickhealthgen() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickhealthgen();

    }

    @Test
    public void Clickfindgroom() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickfindgroom();

    }

    @Test
    public void Clickakcsafe() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakcsafe();

    }

    @Test
    public void Clickakcpet() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakcpet();

    }

    @Test
    public void Clickakcvete() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakcvete();

    }

    @Test
    public void Clickakccanineretreat() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakccanineretreat();

    }

    @Test
    public void Clickakcreunite() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakcreunite();

    }

    @Test
    public void Clickbreedprog() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickbreedprog();

    }

    @Test
    public void Clickbom() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickbom();

    }

    @Test
    public void Clickbwh() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickbwh();

    }

    @Test
    public void Clickbez() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickbez();

    }

    @Test
    public void Clickseall() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickseall();

    }

    @Test
    public void Clickbrowseserv() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickbrowseserv();

    }

    @Test
    public void Clickakcshop() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.Clickakcshop();

    }

    //Test for SportsEvents Menu click action >

    //FIX FROM THIS POINT AND ON >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    @Test
    public void Clickintrodog() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickintrodog();

    }

    @Test
    public void Clickcanpartenro() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickcanpartenro();

    }

    @Test
    public void Clicktitleabrev() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clicktitleabrev();

    }

    @Test
    public void Clickwhichsports() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickwhichsports();

    }

    @Test
    public void Clickgetstartdog() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickgetstartdog();

    }

    @Test
    public void Clickupcomevent() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickupcomevent();

    }

    @Test
    public void Clicknatiotrack() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clicknatiotrack();

    }

    @Test
    public void Clicknatiochamp() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clicknatiochamp();

    }

    @Test
    public void Clickakcagility() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickakcagility();

    }

    @Test
    public void Clickobediencecla() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickobediencecla();

    }

    @Test
    public void Clickakcmeet() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickakcmeet();

    }

    @Test
    public void Clickakcnatobechamp() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickakcnatobechamp();

    }

    @Test
    public void Clickakcrallynatchamp() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickakcrallynatchamp();

    }

    @Test
    public void Clickconfdogshow() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickconfdogshow();

    }

    @Test
    public void Clickmatchshow() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickmatchshow();

    }

    @Test
    public void Clickfourtosix() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickfourtosix();

    }

    @Test
    public void Clickpuppyachiev() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickpuppyachiev();

    }

    @Test
    public void Clicknatiohand() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clicknatiohand();

    }

    @Test
    public void Clickopenshow() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickopenshow();

    }

    @Test
    public void Clickcompsport() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickcompsport();

    }

    @Test
    public void Clickagility() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickagility();

    }

    @Test
    public void Clickobedience() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickobedience();

    }

    @Test
    public void Clickrally() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickrally();

    }

    @Test
    public void Clicktracking() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clicktracking();

    }

    @Test
    public void Clicktittlereco() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clicktittlereco();

    }

    @Test
    public void Clickbarnhunt() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickbarnhunt();

    }

    @Test
    public void Clickdiscdog() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickdiscdog();

    }

    @Test
    public void Clickdivingdog() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickdivingdog();

    }

    @Test
    public void Clickflyball() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickflyball();

    }

    @Test
    public void Clicksearchresc() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clicksearchresc();

    }

    @Test
    public void Clickparentclubrec() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickparentclubrec();

    }

    @Test
    public void Clickperfsport() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickperfsport();

    }

    @Test
    public void Clickfieldevnthound() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickfieldevnthound();

    }

    @Test
    public void Clickcourscat() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickcourscat();

    }

    @Test
    public void Clickearthdog() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickearthdog();

    }

    @Test
    public void Clickherding() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickherding();

    }

    @Test
    public void Clickpointbreed() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickpointbreed();

    }

    @Test
    public void Clickretrievers() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickretrievers();

    }

    @Test
    public void ClickscentWork() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.ClickscentWork();

    }

    @Test
    public void Clickspaniels() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickspaniels();

    }

    @Test
    public void Clicksportsjun() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clicksportsjun();

    }

    @Test
    public void Clickjunshow() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickjunshow();

    }

    @Test
    public void Clickjuncomp() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickjuncomp();

    }

    @Test
    public void Clickjunperf() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickjunperf();

    }

    @Test
    public void Clickpeewee() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickpeewee();

    }

    @Test
    public void Clickakcfamdog() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickakcfamdog();

    }

    @Test
    public void Clickcgcstar() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickcgcstar();

    }

    @Test
    public void ClicktrickVirtual() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.ClicktrickVirtual();

    }

    @Test
    public void ClicktherapyDog() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.ClicktherapyDog();

    }

    @Test
    public void ClickfitDog() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.ClickfitDog();

    }

    @Test
    public void ClicktempTest() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.ClicktempTest();

    }

    @Test
    public void Clickeventse() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickeventse();

    }

    @Test
    public void Clickdownform() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickdownform();

    }

    @Test
    public void Clickrulesreg() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickrulesreg();

    }

    @Test
    public void Clickoem() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickoem();

    }

    @Test
    public void Clickpointaward() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickpointaward();

    }

    @Test
    public void Clickjudgingres() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickjudgingres();

    }

    @Test
    public void Clickjudgesdirec() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickjudgesdirec();

    }

    @Test
    public void Clickjudgeseduc() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickjudgeseduc();

    }

    @Test
    public void Clickakcweeklywin() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickakcweeklywin();

    }

    @Test
    public void Clickeventcanc() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickeventcanc();

    }

    @Test
    public void Clickakccontact() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickakccontact();

    }

    @Test
    public void Clickakcrhp() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.Clickakcrhp();

    }

    //Tests for clubsDelegates menu click action >


    @Test
    public void Clicksearchallclub() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clicksearchallclub();

    }

    @Test
    public void Clickfindanevent() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickfindanevent();

    }

    @Test
    public void Clicktrainclass() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clicktrainclass();

    }

    @Test
    public void Clickaboutclub() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickaboutclub();

    }

    @Test
    public void Clickformclub() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickformclub();

    }

    @Test
    public void Clickclubdevelop() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickclubdevelop();

    }

    @Test
    public void Clickpromoteclub() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickpromoteclub();

    }

    @Test
    public void Clickclubresources() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickclubresources();

    }

    @Test
    public void Clickdelegatespor() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickdelegatespor();

    }

    @Test
    public void Clickdelegatesdir() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickdelegatesdir();

    }

    @Test
    public void Clickdelegatesmeet() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickdelegatesmeet();

    }

    @Test
    public void Clickboardmin() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickboardmin();

    }

    @Test
    public void Clickdelegatestan() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickdelegatestan();

    }

    @Test
    public void Clickperspective() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickperspective();

    }

    @Test
    public void Clickakcgazette() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickakcgazette();

    }

    @Test
    public void Clickrolakcdel() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickrolakcdel();

    }

    @Test
    public void Clickimportance() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickimportance();

    }

    @Test
    public void Clicklegisla() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clicklegisla();

    }

    @Test
    public void Clicklegislaalarm() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clicklegislaalarm();

    }

    @Test
    public void Clickakcpac() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickakcpac();

    }

    @Test
    public void Clickgovernrelat() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickgovernrelat();

    }

    @Test
    public void Clickovercollec() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickovercollec();

    }

    @Test
    public void Clickclubarchives() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickclubarchives();

    }

    @Test
    public void Clicksearchlib() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clicksearchlib();

    }

    @Test
    public void Clickhowtovisit() throws InterruptedException {

        driver.manage().window().maximize();
        clubsDelegates.Clickhowtovisit();

    }

    //Breeds Menu Articles tests >


    @Test
    public void puppiesArticle1() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.puppiesArticle1();

    }

    @Test
    public void puppiesArticle2() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.puppiesArticle2();

    }

    @Test
    public void puppiesArticle3() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.puppiesArticle3();

    }

    @Test
    public void mostpopdogsArticle1() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.mostpopdogsArticle1();

    }

    @Test
    public void mostpopdogsArticle2() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.mostpopdogsArticle2();

    }

    @Test
    public void fordogbreedersArticle1() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.fordogbreedersArticle1();

    }

    @Test
    public void ForDogOwnerArticle1() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.ForDogOwnerArticle1();

    }

    @Test
    public void ForDogOwnerArticle2() throws InterruptedException {

        driver.manage().window().maximize();
        breeds.ForDogOwnerArticle2();

    }

    //ExpertAdvice Menu Articles >


    @Test
    public void allcategArticle() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.allcategArticle();

    }

    @Test
    public void dogbreedArticle() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.dogbreedArticle();

    }

    @Test
    public void healthArticle() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.healthArticle();

    }

    @Test
    public void newsArticle() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.newsArticle();

    }

    @Test
    public void HomelivingArticle() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.HomelivingArticle();

    }

    @Test
    public void lifestyleArticle() throws InterruptedException {

        driver.manage().window().maximize();
        expertAdvice.lifestyleArticle();

    }

    //ProdServ Menu Articles >

    @Test
    public void ProdServArticle1() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.ProdServArticle1();

    }

    @Test
    public void ProdServArticle2() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.ProdServArticle2();

    }

    @Test
    public void ProdServArticle3() throws InterruptedException {

        driver.manage().window().maximize();
        prodserv.ProdServArticle3();

    }

    //SportsEvents Menu Articles >

    @Test
    public void SportsEventsArticle1() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.SportsEventsArticle1();

    }

    @Test
    public void SportsEventArticle2() throws InterruptedException {

        driver.manage().window().maximize();
        sportsEvents.SportsEventArticle2();

    }



}


    





