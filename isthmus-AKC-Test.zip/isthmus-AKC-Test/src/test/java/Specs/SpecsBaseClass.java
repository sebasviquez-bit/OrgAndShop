package Specs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class SpecsBaseClass extends SuperBaseClass {


   /* @Parameters({"environment", "baseURL"})
    @BeforeMethod()
    public void InitializeTests(@Optional String environment, @Optional String baseUrl) throws MalformedURLException {

        if (environment == null)
            environment = "firefox";
        if (baseUrl == null)
            // baseUrl = "https://testingcr-demo.glitch.me/";
            baseUrl = "https://test-web.akc.org/";
*/
        /*if (environment.equals("chrome"))
            driver = new ChromeDriver();
        else
            driver = new InternetExplorerDriver(); */

       // driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

      /*  InitHelpers(baseUrl);
        InitPages();

        driver.get(driverHelper.baseUrl);
    }*/

   /* @AfterMethod
    public void CleanUpDriver() {
        driver.quit();


    }*/


  /*  private WebDriver getDriver(String methodName) throws MalformedURLException
    //private void getDriver(String methodName) throws MalformedURLException {
    {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        String username = "jonathanblanco1";
        String accessKey = "KnTEqZmapCzNS4n9mEns";
        String server = "hub-cloud.browserstack.com";

        DesiredCapabilities caps = new DesiredCapabilities();

        caps.setCapability("name", "Login Form Example");
        caps.setCapability("build", "1.0");
        caps.setCapability("browserName", "Internet Explorer");
        caps.setCapability("version", "11");
        caps.setCapability("platform", "Windows 10");
        caps.setCapability("screenResolution", "1366x768");
        caps.setCapability("record_video", "true");

        if (methodName.contains("Firefox"))

            capabilities.setCapability("browserName","Firefox");
        else
            capabilities.setCapability("browserName","Chrome");

        capabilities.setCapability("name",methodName);

        URL url = new URL("http://" + username + ":" + accessKey + "@" + server + "/wd/hub");

        RemoteWebDriver remoteWebDriver = new RemoteWebDriver(url, caps);
        remoteWebDriver.setFileDetector(new LocalFileDetector());
        return remoteWebDriver;
    }*/

    @BeforeMethod public void InitializeTests(Method method) throws MalformedURLException {

        //driver = getDriver(method.getName());
        driver = new ChromeDriver();
        //driver = new FirefoxDriver();
        //driver = new InternetExplorerDriver();
        //driver = new SafariDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        //InitHelpers("https://test-web.akc.org/");
        InitHelpers("https://www.akc.org/?test=true");
        InitPages();

        driver.get(driverHelper.baseUrl);
        //driver.switchTo().defaultContent();

    }


    @AfterMethod public  void CleanUpDriver(){

        this.driver.get(this.driver.getCurrentUrl()+"?test=true");
        driver.quit();

    }


    private WebDriver getDriver(String methodName) throws MalformedURLException {
        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("username","jonathanblanco1");
        capabilities.setCapability("accesskey","KnTEqZmapCzNS4n9mEns");
        capabilities.setCapability("name", "Login Form Example");
        capabilities.setCapability("build", "1.0");
        // capabilities.setCapability("browserName", "Internet Explorer");
        //capabilities.setCapability("version", "11");
        //capabilities.setCapability("platform", "Windows 10");
        capabilities.setCapability("screenResolution", "1280x1024");
        capabilities.setCapability("record_video", "true");
        //capabilities.setCapability("local","true");

        if (methodName.contains("Firefox"))

            capabilities.setCapability("browserName","Firefox");
        else
            //capabilities.setCapability("browserName","Internet Explorer");
            //capabilities.setCapability("version","11");
            capabilities.setCapability("browserName","Firefox");

        capabilities.setCapability("name",methodName);

        URL url = new URL("https://jonathanblanco1:KnTEqZmapCzNS4n9mEns@hub-cloud.browserstack.com/wd/hub");

        RemoteWebDriver remoteWebDriver = new RemoteWebDriver(url, capabilities);
        remoteWebDriver.setFileDetector(new LocalFileDetector());
        return remoteWebDriver;
    }




}