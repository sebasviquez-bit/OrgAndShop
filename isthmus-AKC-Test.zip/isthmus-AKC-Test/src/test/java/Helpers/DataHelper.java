package Helpers;

import Model.User;
import org.testng.annotations.DataProvider;

public class DataHelper {

    public DataHelper(){
    }
/*
    public User existingUser(){
        return null;
    }

    public User existingUser(){
        return new User("jblanco","123456");
    }*/

    @DataProvider(name="ExistingUsers")
    public static Object[][] credentialsExisting() throws Exception {

       return ExcelHelper.getTableArray("AKCUsers.xlsx","Sheet1", 2);
    }

    @DataProvider(name="FailingUsers")
    public static Object[][] credentialsFailing() throws Exception {

        return CsvHelper.getCSVArray("FailJoLuis.csv");

        //return ExcelHelper.getTableArray("FailJoLuis.csv","Sheet1", 2);
    }

    @DataProvider(name="RegisterUsers")
    public static Object[][] credentialsRegister() throws Exception {

        return CsvHelper.getCSVArray("RegJoLuis.csv");

        //ExcelHelper.getTableArray("RegJoLuis.xlsx","Sheet1", 4);

//        return CsvHelper.getCSVArray("Users.csv");

    }

    @DataProvider(name="WordSearch")
    public static Object[][] searchCriteria() throws Exception {

        return ExcelHelper.getTableArray("Words.xlsx", "Sheet1", 1);
    }
}
