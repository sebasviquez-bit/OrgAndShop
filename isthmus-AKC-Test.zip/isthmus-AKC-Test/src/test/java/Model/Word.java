package Model;

public class Word {


    public String WordSearch;



    public Word(String WordSearch){

        this.WordSearch= WordSearch;
    }


}
